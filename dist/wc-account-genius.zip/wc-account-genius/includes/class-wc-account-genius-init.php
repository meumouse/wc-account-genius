<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Main class autoloader
 * 
 * @package MeuMouse.com
 * @version 1.0.0
 */
class Wc_Account_Genius_Init {

	public $wc_account_genius_settings = array();
  public $responseObj;
  public $licenseMessage;
  public $showMessage = false;
  public $activateLicense = false;
  public $deactivateLicense = false;
  
  public function __construct() {
    // load plugin setting
    if ( empty( $this->wc_account_genius_settings ) ) {
      $this->wc_account_genius_settings = get_option( 'wc-account-genius-setting' );
    }

    // set default tabs options
    add_action( 'plugins_loaded', array( $this, 'set_default_tabs_options' ), 998 );

    // init API class after plugins loaded
    add_action( 'plugins_loaded', array( $this, 'load_api_settings' ), 999 );

    $options = get_option( 'wc-account-genius-setting' );

    // load templates if is active
    if ( isset( $options['replace_default_template_my_account'] ) && $options['replace_default_template_my_account'] === 'yes' ) {
      add_filter( 'woocommerce_locate_template', array( $this, 'replace_my_account_templates' ), 10, 3 );
    }

    add_action( 'wp_enqueue_scripts', array( $this, 'my_account_load_styles' ), 999 );

    // load box icons library
    if ( isset( $options['enable_icons'] ) && $options['enable_icons'] === 'yes' ) {
      add_action( 'wp_enqueue_scripts', array( $this, 'box_icons_lib' ) );
    }

    // load popup avatar
    if ( isset( $options['enable_upload_avatar'] ) && $options['enable_upload_avatar'] === 'yes' ) {
      include_once WC_ACCOUNT_GENIUS_DIR . 'includes/classes/class-wc-account-genius-avatar.php';
      add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_avatar_upload' ) );
    }
  }


  /**
	 * Plugin default settings for texts
   * 
	 * @return array
	 * @since 1.0.0
	 * @access public
	 */
	public $default_settings = array(
    'replace_default_template_my_account' => 'yes',
    'replace_default_notices' => 'yes',
    'primary_main_color' => '#008aff',
    'enable_icons' => 'yes',
    'display_background_slanted' => 'yes',
    'enable_upload_avatar' => 'yes',
  );


  /**
   * Get default tabs
   * 
   * @since 1.8.0
   * @return array $tabs
   */
  public function get_default_tabs() {
    $get_default_endpoints = 

    $tabs = array(
      'orders' => array(
          'id' => 'woocommerce_myaccount_orders_endpoint',
          'endpoint' => get_option('woocommerce_myaccount_orders_endpoint'),
          'icon' => 'bx bx-cart',
          'label' => 'Meus pedidos',
          'native' => 'yes',
          'priority' => '1',
          'enabled' => 'yes',
      ),
      'downloads' => array(
          'id' => 'woocommerce_myaccount_downloads_endpoint',
          'endpoint' => get_option('woocommerce_myaccount_downloads_endpoint'),
          'icon' => 'bx bx-cloud-download',
          'label' => 'Downloads',
          'native' => 'yes',
          'priority' => '2',
          'enabled' => 'yes',
      ),
      'edit-address' => array(
          'id' => 'woocommerce_myaccount_edit_address_endpoint',
          'endpoint' => get_option('woocommerce_myaccount_edit_address_endpoint'),
          'icon' => 'bx bx-map',
          'label' => 'Meus endereços',
          'native' => 'yes',
          'priority' => '3',
          'enabled' => 'yes',
      ),
      'edit-account' => array(
          'id' => 'woocommerce_myaccount_edit_account_endpoint',
          'endpoint' => get_option('woocommerce_myaccount_edit_account_endpoint'),
          'icon' => 'bx bx-user',
          'label' => 'Detalhes da conta',
          'native' => 'yes',
          'priority' => '4',
          'enabled' => 'yes',
      ),
      'payment-methods' => array(
          'id' => 'woocommerce_myaccount_payment_methods_endpoint',
          'endpoint' => get_option('woocommerce_myaccount_payment_methods_endpoint'),
          'icon' => 'bx bx-credit-card-alt',
          'label' => 'Formas de pagamento',
          'native' => 'yes',
          'priority' => '5',
          'enabled' => 'yes',
      ),
      'customer-logout' => array(
          'id' => 'woocommerce_logout_endpoint',
          'endpoint' => get_option('woocommerce_logout_endpoint'),
          'icon' => 'bx bx-log-out',
          'label' => 'Sair',
          'native' => 'yes',
          'priority' => '6',
          'enabled' => 'yes',
      ),
    );

    return $tabs;
  }


  /**
   * Init default options tab
   * 
   * @since 1.8.0
   * @return void
   */
  public function set_default_tabs_options() {
    $default_tabs = $this->get_default_tabs();
    $default_option_tabs = get_option('account_genius_get_tabs_options', array());
    $default_option_tabs = maybe_unserialize($default_option_tabs);

    if ( empty( $default_option_tabs ) ) {
        $tabs = array();

        foreach ( $default_tabs as $key => $value ) {
            $tabs[$key] = $value;
        }

        update_option('account_genius_get_tabs_options', maybe_serialize( $tabs ) );
    } else {
        // Add subscription tab if WC_Subscriptions class is present and tab does not exist
        if ( class_exists('WC_Subscriptions') && !isset( $default_option_tabs['subscription'] ) ) {
            $subscription_tab = array(
                'subscription' => array(
                    'id' => 'woocommerce_myaccount_subscriptions_endpoint',
                    'endpoint' => get_option('woocommerce_myaccount_subscriptions_endpoint'),
                    'icon' => 'bx bx-basket',
                    'label' => 'Minhas assinaturas',
                    'native' => 'yes',
                    'priority' => '7',
                    'enabled' => 'yes',
                ),
            );

            // Add subscription tab to existing options
            $default_option_tabs = array_merge($default_option_tabs, $subscription_tab);
            update_option('account_genius_get_tabs_options', maybe_serialize($default_option_tabs));
        }
    }
  }

  
  /**
	 * Function for get plugin general settings
	 * 
	 * @return string 
	 * @since 1.0.0
	 * @access public
	 */
	public function getSetting( $key ) {
    if ( ! empty( $this->wc_account_genius_settings) && isset( $this->wc_account_genius_settings[ $key ] ) ) {
      return $this->wc_account_genius_settings[ $key ];
    }

    if ( isset( $this->default_settings[ $key ] ) ) {
      return $this->default_settings[ $key ];
    }

    return false;
  }


  /**
   * Replace WooCommerce templates in my account page
   * 
   * @since 1.0.0
   * @param string $template
   * @param string $template_name
   * @param string $template_path
   * @return string $template
   */
  public function replace_my_account_templates( $template, $template_name, $template_path ) {
    $options = get_option( 'wc-account-genius-setting' );
    
    // replace downloads template
    if ( $template_name === 'myaccount/downloads.php' ) {
      $template = WC_ACCOUNT_GENIUS_DIR . '/includes/templates/my-account/downloads.php';
    }

    // replace form edit account template
    if ( $template_name === 'myaccount/form-edit-account.php' ) {
      $template = WC_ACCOUNT_GENIUS_DIR . '/includes/templates/my-account/form-edit-account.php';
    }

    // replace form edit address template
    if ( $template_name === 'myaccount/form-edit-address.php' ) {
      $template = WC_ACCOUNT_GENIUS_DIR . '/includes/templates/my-account/form-edit-address.php';
    }

    // replace form login template
    if ( is_account_page() && $template_name === 'myaccount/form-login.php' ) {
      $template = WC_ACCOUNT_GENIUS_DIR . '/includes/templates/my-account/form-login.php';
    }

    // replace form lost password template
    if ( $template_name === 'myaccount/form-lost-password.php' ) {
      $template = WC_ACCOUNT_GENIUS_DIR . '/includes/templates/my-account/form-lost-password.php';
    }

    // replace form lost password confirmation template
    if ( $template_name === 'myaccount/lost-password-confirmation.php' ) {
      $template = WC_ACCOUNT_GENIUS_DIR . '/includes/templates/my-account/lost-password-confirmation.php';
    }

    // replace my account template
    if ( $template_name === 'myaccount/my-account.php' ) {
      $template = WC_ACCOUNT_GENIUS_DIR . '/includes/templates/my-account/my-account.php';
    }

    // replace my addresses template
    if ( $template_name === 'myaccount/my-address.php' ) {
      $template = WC_ACCOUNT_GENIUS_DIR . '/includes/templates/my-account/my-address.php';
    }

    // replace navigation template
    if ( $template_name === 'myaccount/navigation.php' ) {
      $template = WC_ACCOUNT_GENIUS_DIR . '/includes/templates/my-account/navigation.php';
    }

    // replace orders template
    if ( $template_name === 'myaccount/orders.php' ) {
      $template = WC_ACCOUNT_GENIUS_DIR . '/includes/templates/my-account/orders.php';
    }

    // replace view order template
    if ( $template_name === 'myaccount/view-order.php' ) {
      $template = WC_ACCOUNT_GENIUS_DIR . '/includes/templates/my-account/view-order.php';
    }

    // replace form tracking template
    if ( $template_name === 'order/form-tracking.php' ) {
      $template = WC_ACCOUNT_GENIUS_DIR . '/includes/templates/order/form-tracking.php';
    }

    // replace order again template
    if ( $template_name === 'order/order-again.php' ) {
      $template = WC_ACCOUNT_GENIUS_DIR . '/includes/templates/order/order-again.php';
    }

    // replace order details template
    if ( $template_name === 'order/order-details.php' ) {
      $template = WC_ACCOUNT_GENIUS_DIR . '/includes/templates/order/order-details.php';
    }

    // replace order details customer template
    if ( $template_name === 'order/order-details-customer.php' ) {
      $template = WC_ACCOUNT_GENIUS_DIR . '/includes/templates/order/order-details-customer.php';
    }

    // replace order details item template
    if ( $template_name === 'order/order-details-item.php' ) {
      $template = WC_ACCOUNT_GENIUS_DIR . '/includes/templates/order/order-details-item.php';
    }

    // replace order downloads template
    if ( $template_name === 'order/order-downloads.php' ) {
      $template = WC_ACCOUNT_GENIUS_DIR . '/includes/templates/order/order-downloads.php';
    }

    // replace tracking template
    if ( $template_name === 'order/tracking.php' ) {
      $template = WC_ACCOUNT_GENIUS_DIR . '/includes/templates/order/tracking.php';
    }

    // replace my subscriptions template  
    if ( class_exists( 'WC_Subscriptions' ) && $template_name === 'myaccount/my-subscriptions.php' ) {
      $template = WC_ACCOUNT_GENIUS_DIR . '/includes/templates/my-account/my-subscriptions.php';
    }

    if ( is_account_page() ) {
        // replace error notice template
        if ( isset( $options['replace_default_notices'] ) && $options['replace_default_notices'] == 'yes' && $template_name === 'notices/error.php' ) {
          $template = WC_ACCOUNT_GENIUS_DIR . '/includes/templates/notices/error.php';
        }

        // replace success notice template
        if ( isset( $options['replace_default_notices'] ) && $options['replace_default_notices'] == 'yes' && $template_name === 'notices/success.php' ) {
          $template = WC_ACCOUNT_GENIUS_DIR . '/includes/templates/notices/success.php';
        }

        // replace info notice template
        if ( isset( $options['replace_default_notices'] ) && $options['replace_default_notices'] == 'yes' && $template_name === 'notices/notice.php' ) {
          $template = WC_ACCOUNT_GENIUS_DIR . '/includes/templates/notices/notice.php';
        }
    }

    return $template;
  }


  /**
   * Load styles in My account page
   * 
   * @since 1.0.0
   * @return void
   */
  public function my_account_load_styles() {
    $options = get_option( 'wc-account-genius-setting' );

    if ( is_account_page() && isset( $options['replace_default_template_my_account'] ) && $options['replace_default_template_my_account'] == 'yes' ) {
      wp_enqueue_style( 'wc-account-genius-front-styles', WC_ACCOUNT_GENIUS_URL . 'assets/front/css/wc-account-genius-front-styles.css', array(), WC_ACCOUNT_GENIUS_VERSION );
      wp_enqueue_script( 'wc-account-genius-front-scripts', WC_ACCOUNT_GENIUS_URL . 'assets/front/js/wc-account-genius-front-scripts.js', array('jquery'), WC_ACCOUNT_GENIUS_VERSION );
    }
  }
  

  /**
   * Load Boxicons library
   * 
   * @since 1.0.0
   * @return void
   */
  public function box_icons_lib() {
    wp_enqueue_style( 'boxicons-lib', WC_ACCOUNT_GENIUS_URL . 'assets/vendor/boxicons/css/boxicons.min.css', array(), '2.1.4' );
  }


  /**
   * Load upload avatar styles and scripts
   * 
   * @since 1.0.0
   * @return void
   */
  public function enqueue_avatar_upload() {
    wp_enqueue_style( 'wc-account-genius-avatar-styles', WC_ACCOUNT_GENIUS_URL . 'assets/front/css/wc-account-genius-popup-avatar-styles.css', array(), WC_ACCOUNT_GENIUS_VERSION );
    wp_enqueue_script( 'wc-account-genius-avatar-scripts', WC_ACCOUNT_GENIUS_URL . 'assets/front/js/wc-account-genius-popup-avatar-scripts.js', array(), WC_ACCOUNT_GENIUS_VERSION );
  }


  /**
   * Load API settings
   * 
   * @since 1.0.0
   * @version 1.8.0
   */
  public function load_api_settings() {
    if ( current_user_can('manage_woocommerce') ) {
      $this->responseObj = new stdClass();
      $this->responseObj->is_valid = false;
  
      $license_key = get_option( 'wc_account_genius_license_key', '' );
  
      // Save settings on active license
      if (  isset( $_POST['wc_account_genius_active_license'] ) ) {
          update_option( 'wc_account_genius_license_key', $_POST );
          $license_key = !empty( $_POST['wc_account_genius_license_key'] ) ? $_POST['wc_account_genius_license_key'] : '';
          update_option( 'wc_account_genius_license_key', $license_key ) || add_option('wc_account_genius_license_key', $license_key );
          update_option( '_site_transient_update_plugins', '' );
      }

      if ( get_option( 'wc_account_genius_license_status' ) !== 'valid' ) {
        update_option( 'wc_account_genius_license_key', '' );
        update_option( 'wc_account_genius_license_status', 'invalid' );
      }
  
      // Check on the server if the license is valid and update responses and options
      if ( Wc_Account_Genius_Api::CheckWPPlugin( $license_key, $this->licenseMessage, $this->responseObj, __FILE__ ) ) {
          if ( $this->responseObj && $this->responseObj->is_valid ) {
            update_option( 'wc_account_genius_license_status', 'valid' );
          } else {
            update_option( 'wc_account_genius_license_status', 'invalid' );
            wp_cache_delete( 'wc_account_genius_url_server_cache' );
          }

          if ( isset( $_POST['wc_account_genius_active_license'] ) && $this->responseObj && $this->responseObj->is_valid ) {
            $this->activateLicense = true;
          }
      } else {
          if ( !empty( $license_key ) && !empty( $this->licenseMessage ) ) {
              $this->showMessage = true;
          }
      }

      // Save settings on deactive license, or remove license status if it is invalid
      if ( isset( $_POST['wc_account_genius_deactive_license'] ) ) {
        if ( Wc_Account_Genius_Api::RemoveLicenseKey( __FILE__, $message ) ) {
          update_option( 'wc_account_genius_license_status', 'invalid' );
          delete_option( 'wc_account_genius_license_key' );
          update_option( '_site_transient_update_plugins', '' );
          wp_cache_delete( 'wc_account_genius_url_server_cache' );

          $this->deactivateLicense = true;
        }
      }

      // clear activation cache
      if ( get_option( 'wc_account_genius_license_status' ) !== 'valid' ) {
        delete_transient('wc_account_genius_api_request_cache');
        delete_transient('wc_account_genius_api_response_cache');
      }
    }
  }

}

new Wc_Account_Genius_Init();