<?php
/**
 * My Account navigation
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/navigation.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package MeuMouse.com
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

do_action( 'woocommerce_before_account_navigation' );

?>

<div class="d-lg-block collapse pb-2" id="account-menu">
	
	 <?php foreach ( wc_get_account_menu_items() as $endpoint => $label ) : ?>
			<?php if ( $endpoint === 'dashboard' ) : ?>
				<h3 class="d-block bg-secondary fs-sm fw-semibold text-muted mb-0 px-4 py-3"><a href="<?php echo esc_url( wc_get_account_endpoint_url( $endpoint ) ); ?>" class="<?php echo wc_get_account_menu_item_classes( $endpoint ); ?> text-muted"><?php echo esc_html__( 'Painel', 'wc-account-genius'); ?></a></h3>
				
			<?php elseif ( $endpoint === 'orders' ) : ?>
				<a href="<?php echo esc_url( wc_get_account_endpoint_url( $endpoint ) ); ?>" class="<?php echo wc_get_account_menu_item_classes( $endpoint ); ?> d-flex align-items-center nav-link-style px-4 py-3">
					<i class="bx bx-cart fs-lg opacity-60 me-2"></i>
					<?php echo esc_html( 'Pedidos', 'wc-account-genius' ); ?>
					<span class="text-muted fs-sm fw-normal ms-auto"><?php wc_account_genius_orders_count(); ?></span>
				</a>

			<?php elseif ( $endpoint === 'downloads' ) : ?>
				<a href="<?php echo esc_url( wc_get_account_endpoint_url( $endpoint ) ); ?>" class="<?php echo wc_get_account_menu_item_classes( $endpoint ); ?> d-flex align-items-center nav-link-style px-4 py-3 border-top">
					<i class="bx bx-cloud-download fs-lg opacity-60 me-2"></i>
					<?php echo esc_html( 'Downloads', 'wc-account-genius' ); ?>
					<span class="text-muted fs-sm fw-normal ms-auto"><?php wc_account_genius_downloads_count(); ?></span>
				</a>

			<?php elseif ( $endpoint === 'edit-address' ) : ?>
				<a href="<?php echo esc_url( wc_get_account_endpoint_url( $endpoint ) ); ?>" class="<?php echo wc_get_account_menu_item_classes( $endpoint ); ?> d-flex align-items-center nav-link-style px-4 py-3 border-top">
					<i class="bx bx-map fs-lg opacity-60 me-2"></i>
					<?php echo esc_html( 'Meus endereços', 'wc-account-genius' ); ?>
				</a>
			
			<?php elseif ( $endpoint === 'edit-account' ) : ?>
				<a href="<?php echo esc_url( wc_get_account_endpoint_url( $endpoint ) ); ?>" class="<?php echo wc_get_account_menu_item_classes( $endpoint ); ?> d-flex align-items-center nav-link-style px-4 py-3 border-top">
					<i class="bx bx-user fs-lg opacity-60 me-2"></i>
					<?php echo esc_html( 'Detalhes da conta', 'wc-account-genius' ); ?>
				</a>
				
			<?php elseif ( $endpoint === 'payment-methods' ) : ?>
				<a href="<?php echo esc_url( wc_get_account_endpoint_url( $endpoint ) ); ?>" class="<?php echo wc_get_account_menu_item_classes( $endpoint ); ?> d-flex align-items-center nav-link-style px-4 py-3 border-top">
					<i class="bx bx-credit-card-alt fs-lg opacity-60 me-2"></i>
					<?php echo esc_html( 'Formas de pagamento', 'wc-account-genius' ); ?>
				</a>
			
			<?php elseif ( $endpoint === 'customer-logout' ) : ?>
				<a href="<?php echo esc_url( wc_get_account_endpoint_url( $endpoint ) ); ?>" class="<?php echo wc_get_account_menu_item_classes( $endpoint ); ?> d-flex align-items-center nav-link-style px-4 py-3 border-top">
					<i class="bx bx-log-out fs-lg opacity-60 me-2"></i>
					<?php echo esc_html( 'Sair', 'wc-account-genius' ); ?>
				</a>
				
			<?php endif; ?>
		<?php endforeach; ?>
</div>
	

<?php do_action( 'woocommerce_after_account_navigation' ); ?>
