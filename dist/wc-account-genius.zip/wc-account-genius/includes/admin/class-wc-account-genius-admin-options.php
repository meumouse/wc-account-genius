<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

class Wc_Account_Genius_Admin_Options extends Wc_Account_Genius_Init {

  /**
   * Wc_Account_Genius_Admin constructor.
   *
   * @since 1.0.0
   * @access public
   */
  public function __construct() {
    parent::__construct();

    add_action( 'admin_menu', array( $this, 'wc_account_genius_admin_menu' ) );
    add_action( 'admin_enqueue_scripts', array( $this, 'wc_account_genius_admin_scripts' ) );
    add_action( 'wp_ajax_account_genius_ajax_save_options', array( $this, 'account_genius_ajax_save_options_callback' ) );
    add_action( 'wp_ajax_nopriv_account_genius_ajax_save_options', array( $this, 'account_genius_ajax_save_options_callback' ) );
  }

  /**
   * Function for create submenu in settings
   * 
   * @since 1.0.0
   * @access public
   * @return array
   */
  public function wc_account_genius_admin_menu() {
    add_submenu_page(
      'woocommerce', // parent page slug
      esc_html__( 'Account Genius para WooCommerce', 'wc-account-genius'), // page title
      esc_html__( 'Account Genius', 'wc-account-genius'), // submenu title
      'manage_woocommerce', // user capabilities
      'wc-account-genius', // page slug
      array( $this, 'wc_account_genius_settings_page' ) // public function for print content page
    );
  }


  /**
   * Plugin general setting page and save options
   * 
   * @since 1.0.0
   * @access public
   */
  public function wc_account_genius_settings_page() {
    include_once WC_ACCOUNT_GENIUS_DIR . 'includes/admin/settings.php';
  }


  /**
   * Enqueue admin scripts in page settings only
   * 
   * @since 1.0.0
   * @access public
   * @return void
   */
  public function wc_account_genius_admin_scripts() {
    $url = $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    
    if ( false !== strpos( $url, 'admin.php?page=wc-account-genius' ) ) {
      wp_enqueue_script( 'wc-account-genius-admin-scripts', WC_ACCOUNT_GENIUS_URL . 'assets/js/wc-account-genius-admin-scripts.js', array('jquery'), WC_ACCOUNT_GENIUS_VERSION );
      wp_enqueue_style( 'wc-account-genius-admin-styles', WC_ACCOUNT_GENIUS_URL . 'assets/css/wc-account-genius-admin-styles.css', array(), WC_ACCOUNT_GENIUS_VERSION );
    
      wp_localize_script( 'wc-account-genius-admin-scripts', 'account_genius_admin_params', array(
        'ajax_url' => admin_url( 'admin-ajax.php' ),
      ) );
    }
  }


  /**
   * Save options in AJAX
   * 
   * @since 1.5.0
   * @return void
   * @package MeuMouse.com
   */
  public function account_genius_ajax_save_options_callback() {
    if ( isset( $_POST['form_data'] ) ) {
        // Convert serialized data into an array
        parse_str( $_POST['form_data'], $form_data );

        $options = get_option( 'wc-account-genius-setting' );
        $options['replace_default_template_my_account'] = isset( $form_data['replace_default_template_my_account'] ) ? 'yes' : 'no';
        $options['replace_default_notices'] = isset( $form_data['replace_default_notices'] ) ? 'yes' : 'no';
        $options['enable_icons'] = isset( $form_data['enable_icons'] ) ? 'yes' : 'no';
        $options['display_background_slanted'] = isset( $form_data['display_background_slanted'] ) ? 'yes' : 'no';
        $options['enable_upload_avatar'] = isset( $form_data['enable_upload_avatar'] ) ? 'yes' : 'no';

        // Merge the form data with the default options
        $updated_options = wp_parse_args( $form_data, $options );

        // Save the updated options
        update_option( 'wc-account-genius-setting', $updated_options );

        $response = array(
          'status' => 'success',
          'options' => $updated_options,
        );

        echo wp_json_encode( $response ); // Send JSON response
    }

    wp_die();
  }

}

new Wc_Account_Genius_Admin_Options();