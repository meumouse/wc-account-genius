<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
  exit; }

class Wc_Account_Genius_Admin_Options extends Wc_Account_Genius_Autoloader {

  /**
   * Wc_Account_Genius_Admin constructor.
   *
   * @since 1.0.0
   * @access public
   */
  public function __construct() {
    parent::__construct();

    add_action( 'admin_menu', array( $this, 'wc_account_genius_admin_menu' ) );
    add_action( 'admin_enqueue_scripts', array( $this, 'wc_account_genius_admin_scripts' ) );
  }

  /**
   * Function for create submenu in settings
   * 
   * @since 1.0.0
   * @access public
   * @return array
   */
  public function wc_account_genius_admin_menu() {
    add_submenu_page(
      'woocommerce', // parent page slug
      esc_html__( 'Account Genius', 'wc-account-genius'), // page title
      esc_html__( 'Account Genius', 'wc-account-genius'), // submenu title
      'manage_woocommerce', // user capabilities
      'wc-account-genius', // page slug
      array( $this, 'wc_account_genius_settings_page' ) // public function for print content page
    );
  }


  /**
   * Plugin general setting page and save options
   * 
   * @since 1.0.0
   * @access public
   */
  public function wc_account_genius_settings_page() {
    $settingSaves = false;

    // Save global options
    if( current_user_can( 'manage_options' ) && isset( $_POST[ 'save_settings' ] ) ) {
      update_option( 'wc-account-genius-setting', $_POST );
      $this->wc_account_genius_settings = $_POST;

      $settingSaves = true;
    }

    $options = get_option( 'wc-account-genius-setting' );

    include_once WC_ACCOUNT_GENIUS_DIR . 'includes/admin/settings.php';
  }


  /**
   * Enqueue admin scripts in page settings only
   * 
   * @since 1.0.0
   * @access public
   * @return void
   */
  public function wc_account_genius_admin_scripts() {
    $url = $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    $version = Wc_Account_Genius()->version;
    
    if ( false !== strpos( $url, 'admin.php?page=wc-account-genius' ) ) {
      wp_enqueue_script( 'wc-account-genius-admin-scripts', WC_ACCOUNT_GENIUS_URL . 'assets/js/wc-account-genius-admin-scripts.js', array('jquery'), $version );
      wp_enqueue_style( 'wc-account-genius-admin-styles', WC_ACCOUNT_GENIUS_URL . 'assets/css/wc-account-genius-admin-styles.css', array(), $version );
    }
  }

}

new Wc_Account_Genius_Admin_Options();