<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit; } ?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">

<div class="d-flex">
    <h1 class="wc-account-genius-admin-section-tile"><?php echo get_admin_page_title() ?></h1>
</div>

<div class="wc-account-genius-admin-title-description">
    <p><?php echo esc_html__( 'Extensão que altera o modelo de página minha conta padrão do WooCommerce por um modelo profissional e responsivo. Se precisar de ajuda para configurar, acesse nossa', 'wc-account-genius' ) ?>
        <a class="fancy-link" href="https://meumouse.com/docs/plugins/account-genius/" target="_blank"><?php echo esc_html__( 'Central de ajuda', 'wc-account-genius' ) ?></a>
    </p>
</div>

<?php

    if( $settingSaves === true) { ?>
        <div class="toast update-notice-spm-wp">
            <div class="toast-header bg-success text-white">
                <i class="fa-regular fa-circle-check me-3"></i>
                <span class="me-auto"><?php _e( 'Salvo com sucesso', 'wc-account-genius' ); ?></span>
                <button class="btn-close btn-close-white ms-2 hide-toast" type="button" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body"><?php _e( 'As configurações foram atualizadas!', 'wc-account-genius' ); ?></div>
        </div>
        <?php
    }

    settings_errors(); ?>

<div class="wc-account-genius-wrapper">
    <form method="post" action="" class="wc-account-genius-form" name="wc-account-genius">
        <input type="hidden" name="wc-account-genius" value="1"/>
        <?php
        include_once WC_ACCOUNT_GENIUS_DIR . 'includes/admin/options.php';
        ?>
        <button id="save_settings" name="save_settings" class="btn btn-primary m-5 button-loading" type="submit">
            <span class="span-inside-button-loader"><?php esc_attr_e( 'Salvar alterações', 'wc-account-genius' ); ?></span>
        </button>
    </form>
</div>