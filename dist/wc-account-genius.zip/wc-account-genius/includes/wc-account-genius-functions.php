<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Get downloads count
 * 
 * @since 1.0.0
 * @return void
 */
if ( ! function_exists( 'wc_account_genius_downloads_count' ) ) {
  function wc_account_genius_downloads_count() {
      $downloads = WC()->customer->get_downloadable_products();

      echo count( $downloads );
  }
}

/**
 * Get orders count
 * 
 * @since 1.0.0
 * @return void
 */
if ( ! function_exists( 'wc_account_genius_orders_count' ) ) {
  function wc_account_genius_orders_count() {
      $orders = wc_get_orders( apply_filters( 'wc_account_genius_orders_count_args', [
          'status' => [ 'pending', 'processing', 'completed', 'on-hold', 'failed' ],
          'customer' => get_current_user_id(),
          'return' => 'ids',
          'limit' => - 1,
          'paginate' => false,
      ] ) );

      echo count( $orders );
  }
}

/**
 * Display endpoint titles in My account page
 * 
 * @since 1.0.0
 * @return string
 */
if ( ! function_exists( 'wc_account_genius_endpoint_titles' ) ) {
    function wc_account_genius_endpoint_titles() {
        global $wp;

        $endpoints = wc_get_account_menu_items();
        $title = esc_html_x( 'Minha conta', 'front-end', 'wc-account-genius' );

        foreach ( $endpoints as $endpoint => $label ) {
            if ( isset( $wp->query_vars[ $endpoint ] ) ) {
                $title = $label;
            } elseif ( isset( $wp->query_vars['orders'] ) ) {
                $title = esc_html_x( 'Histórico de pedidos', 'front-end', 'wc-account-genius' );
                break;
            } elseif ( isset( $wp->query_vars['payment-methods'] ) ) {
                $title = esc_html_x( 'Métodos de pagamento', 'front-end', 'wc-account-genius' );
                break;
            } elseif ( isset( $wp->query_vars['edit-address'] ) ) {
                $title = esc_html_x( 'Meus endereços', 'front-end', 'wc-account-genius' );
                break;
            } elseif ( isset( $wp->query_vars['page'] ) || empty( $wp->query_vars ) ) {
                // Dashboard is not an endpoint, so needs a custom check.
                $title = esc_html_x( 'Painel', 'front-end', 'wc-account-genius' );
                break;
            }
        }

        echo apply_filters( 'wc_account_genius_endpoint_titles', $title );
    }
}

/**
 * Order item name in WooCommerce orders
 * 
 * @since 1.0.0
 * @param string $name
 * @return object
 */
if ( ! function_exists( 'wc_account_genius_order_item_name' ) ) {
  function wc_account_genius_order_item_name( $name, $item ){
      $variation_id = $item['variation_id'];

      if ( $variation_id > 0 ) {
          $product_id = $item['product_id'];
          $_product = wc_get_product( $product_id );
          $product_name = $_product->get_title();
          $_name = $product_name;
          $variation_name = str_replace( $product_name . ' -', '', $item->get_name() );
          $_name .= '<span class="text-muted d-block mt-1 fw-normal">'. $variation_name .'</span>';
          $updated_name = str_replace( $item->get_name(), $_name, $name );
          $name = $updated_name;
      }
      
      return $name;
  }
}

add_filter( 'woocommerce_order_item_name', 'wc_account_genius_order_item_name', 10, 2 );

/**
 * Get posts per page in WooCommerce My account
 * 
 * @since 1.0.0
 * @return object
 */
if ( ! function_exists( 'wc_account_genius_my_account_orders_limit' ) ) {
    function wc_account_genius_my_account_orders_limit( $args ) {
        // Set the posts per page
        $args['posts_per_page'] = wc_account_genius_orders_limit();

        return $args;
    }
}

if ( ! function_exists( 'wc_account_genius_orders_limit' ) ) {
    function wc_account_genius_orders_limit() {
        return apply_filters( 'wc_account_genius_orders_limit', 5 );
    }
}

/**
 * Display slanted background in My account page
 * 
 * @since 1.0.0
 * @return void
 */
function wc_account_genius_enqueue_scripts() {
    $options = get_option('wc-account-genius-setting');

    if ( is_account_page() && isset( $options['display_background_slanted'] ) && $options['display_background_slanted'] == 'yes' ) {
        $css = '.wc-account-genius-my-account::before, .wc-account-genius-form-login::before, .wc-account-genius-form-last-password::before {
                content: "";
                position: absolute;
                width: 100%;
                height: 50vh;
                top: 0;
                right: 0;
                z-index: -1;
                background-color: #008aff;
        }';

        $css .= '.wc-account-genius-my-account::after, .wc-account-genius-form-login::after, .wc-account-genius-form-last-password::after {
            content: "";
            position: absolute;
            width: 100%;
            height: 20vh;
            top: 40vh;
            right: 0;
            z-index: -1;
            background-color: #008aff;
            transform: skewY(-8deg);
            -webkit-transform: skewY(-8deg);
        }';

        $css .= '@media (min-width: 992px) {
            .wc-account-genius-my-account::before, .wc-account-genius-form-login::before, .wc-account-genius-form-last-password::before {
                height: 300px;
            }

            .wc-account-genius-my-account::after, .wc-account-genius-form-login::after, .wc-account-genius-form-last-password::after {
                height: 350px;
                top: 20vh;
                transform: skewY(-5deg);
                -webkit-transform: skewY(-5deg);
        }}';

        ?>
        <style type="text/css">
            <?php echo $css; ?>
        </style> <?php
    }
}

add_action('wp_head', 'wc_account_genius_enqueue_scripts');

/**
 * Adds new WooCommerce account tab and corresponding rendering function
 * 
 * @since 1.8.0
 * @param string $endpoint | Endpoint for new tab
 * @param string $label | Label for new tab
 * @param string $content_callback | Callback function to render tab content
 * @param string $icon | (Optional) Icon for new tab
 * @return void
 */
function add_new_account_tab( $endpoint, $label, $content_callback, $icon = '' ) {
    add_filter('woocommerce_account_menu_items', function( $items ) use ( $endpoint, $label, $icon ) {
        $new_item = array(
            $endpoint => $label,
        );

        // display icon if different of empty
        if ( !empty( $icon ) ) {
            $new_item[$endpoint] = '<i class="' . $icon . '"></i> ' . $label;
        }

        $items = array_slice( $items, 0, 1, true ) + $new_item + array_slice( $items, 1, count( $items ) - 1, true );

        return $items;
    });

    // add action to corresponding render function
    $key = 'woocommerce_account_' . $endpoint . '_endpoint';

    // render tab content
    add_action( $key, $content_callback );

    // add rewrite endpoint
    add_rewrite_endpoint( $endpoint, EP_ROOT | EP_PAGES );

    // add rewrite rules for new endpoint
    add_rewrite_rule(
        '^' . $endpoint . '/?$',
        'index.php?pagename=' . $endpoint,
        'top'
    );

    // update permalinks
    flush_rewrite_rules();
}

/**
 * Renders tab content dynamically
 * 
 * @since 1.8.0
 * @return void
 */
function render_new_tab_content() {
    if ( is_user_logged_in() ) {
        $account_tabs = get_option('account_genius_get_tabs_options', array());
        $account_tabs = maybe_unserialize( $account_tabs );
        $url = $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];

        foreach ( $account_tabs as $index => $tab ) {
            // ignore if is native tab
            if ( isset( $tab['native'] ) && $tab['native'] === 'yes' ) {
                continue;
            }

            // check if current tab not is redirect link and is same endpoint with current URL
            if ( isset( $tab['link'] ) && $tab['link'] !== 'yes' && false !== strpos( $url, $tab['endpoint'] ) ) {
                // check content
                if ( preg_match( '/\[[a-zA-Z0-9_]+/', $tab['content'] ) ) {
                    // if is shortcode, then display
                    echo do_shortcode( $tab['content'] );
                    break;
                } else {
                    // If not a shortcode, display as HTML content
                    echo $tab['content'];
                    break;
                }
            }
        }
    }
}

/**
 * Renders account tabs and corresponding content
 * 
 * @since 1.8.0
 * @return void
 */
function render_account_tabs() {
    $account_tabs = get_option('account_genius_get_tabs_options', array());
    $account_tabs = maybe_unserialize( $account_tabs );

    foreach ( $account_tabs as $index => $tab ) {
        if ( isset( $tab['native'] ) && $tab['native'] === 'no' ) {
            add_new_account_tab( $tab['endpoint'], $tab['label'], 'render_new_tab_content', $tab['icon'], );
        }
    }
}

// Add action to render account tabs
add_action( 'init', 'render_account_tabs' );