<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
  exit; }


/**
 * Get downloads count
 * 
 * @since 1.0.0
 * @return string
 * @package MeuMouse.com
 */
if ( ! function_exists( 'wc_account_genius_downloads_count' ) ) {
  function wc_account_genius_downloads_count() {
      $downloads = WC()->customer->get_downloadable_products();
      echo count( $downloads );
  }
}

/**
 * Get orders count
 * 
 * @since 1.0.0
 * @return string
 * @package MeuMouse.com
 */
if ( ! function_exists( 'wc_account_genius_orders_count' ) ) {
  function wc_account_genius_orders_count() {
      $orders = wc_get_orders( apply_filters( 'wc_account_genius_orders_count_args', [
          'status'   => [ 'pending', 'processing', 'completed', 'on-hold', 'failed' ],
          'customer' => get_current_user_id(),
          'return'   => 'ids',
          'limit'    => - 1,
          'paginate' => false,
      ] ) );

      echo count( $orders );
  }
}

/**
 * Display endpoint titles in My account page
 * 
 * @since 1.0.0
 * @return string
 * @package MeuMouse.com
 */
if ( ! function_exists( 'wc_account_genius_endpoint_titles' ) ) {
    function wc_account_genius_endpoint_titles() {
        global $wp;

        $endpoints = wc_get_account_menu_items();
        $title = esc_html_x( 'Minha conta', 'front-end', 'wc-account-genius' );

        foreach ( $endpoints as $endpoint => $label ) {
            if ( isset( $wp->query_vars[ $endpoint ] ) ) {
                $title = $label;
            } elseif ( isset( $wp->query_vars['orders'] ) ) {
                $title = esc_html_x( 'Histórico de pedidos', 'front-end', 'wc-account-genius' );
                break;
            } elseif ( isset( $wp->query_vars['add-payment-method'] ) ) {
                $title = esc_html_x( 'Métodos de pagamento', 'front-end', 'wc-account-genius' );
                break;
            } elseif ( isset( $wp->query_vars['edit-address'] ) ) {
                $title = esc_html_x( 'Meus endereços', 'front-end', 'wc-account-genius' );
                break;
            } elseif ( isset( $wp->query_vars['page'] ) || empty( $wp->query_vars ) ) {
                // Dashboard is not an endpoint, so needs a custom check.
                $title = esc_html_x( 'Painel', 'front-end', 'wc-account-genius' );
                break;
            }
        }

        echo apply_filters( 'wc_account_genius_endpoint_titles', $title );
    }
}

/**
 * Order item name in WooCommerce orders
 * 
 * @since 1.0.0
 * @param string $name
 * @return object
 * @package MeuMouse.com
 */
if ( ! function_exists( 'wc_account_genius_order_item_name' ) ) {
  function wc_account_genius_order_item_name( $name, $item ){
      $variation_id = $item['variation_id'];
      if( $variation_id > 0 ) {
          $product_id = $item['product_id'];
          $_product = wc_get_product( $product_id );
          $product_name = $_product->get_title();
          $_name = $product_name;
          $variation_name = str_replace( $product_name . ' -', '', $item->get_name() );
          $_name .= '<span class="text-muted d-block mt-1 fw-normal">'. $variation_name .'</span>';
          $updated_name = str_replace( $item->get_name(), $_name, $name );
          $name = $updated_name;
      }
      
      return $name;
  }
}
add_filter( 'woocommerce_order_item_name', 'wc_account_genius_order_item_name', 10, 2 );

/**
 * Get posts per page in WooCommerce My account
 * 
 * @since 1.0.0
 * @return object
 * @package MeuMouse.com
 */
if ( ! function_exists( 'wc_account_genius_my_account_orders_limit' ) ) {
    function wc_account_genius_my_account_orders_limit( $args ) {
        // Set the posts per page
        $args['posts_per_page'] = wc_account_genius_orders_limit();
        return $args;
    }
}

if ( ! function_exists( 'wc_account_genius_orders_limit' ) ) {
    function wc_account_genius_orders_limit() {
        return apply_filters( 'wc_account_genius_orders_limit', 5 );
    }
}

/**
 * Display slanted background in My account page
 * 
 * @since 1.0.0
 * @return string
 * @package MeuMouse.com
 */
function wc_account_genius_enqueue_scripts() {
    $options = get_option('wc-account-genius-setting');

    if ( is_account_page() && isset( $options['display_background_slanted'] ) == 'yes' ) {
        $css = '.wc-account-genius-my-account::before, .wc-account-genius-form-login::before, .wc-account-genius-form-last-password::before {
            position: absolute;
            content: "";
            width: 1000%;
            height: 100%;
            top: 0;
            right: 0;
            z-index: -1;
            background-color: #008aff;
            -webkit-transform: skew(96deg, 180deg);
            -moz-transform: skew(96deg, 180deg);
            -ms-transform: skew(96deg, 180deg);
            -o-transform: skew(96deg, 180deg);
            transform: skew(96deg, 180deg);
            transition: height 0.35s ease-in-out;
        }';

        $css .= '@media (max-width: 992px) {
            .wc-account-genius-my-account::before, .wc-account-genius-form-login::before, .wc-account-genius-form-last-password::before {
            height: 100%;
            -webkit-transform: skew(96deg, 185deg);
            -moz-transform: skew(96deg, 185deg);
            -ms-transform: skew(96deg, 185deg);
            -o-transform: skew(96deg, 185deg);
            transform: skew(96deg, 185deg);
        }}';

        ?>
        <style type="text/css">
            <?php echo $css; ?>
        </style> <?php
    }
}
add_action('wp_head', 'wc_account_genius_enqueue_scripts');