<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
  exit; }


/**
 * Get downloads count
 * 
 * @since 1.0.0
 * @return string
 */
if ( ! function_exists( 'wc_account_genius_downloads_count' ) ) {
  function wc_account_genius_downloads_count() {
      $downloads = WC()->customer->get_downloadable_products();
      echo count( $downloads );
  }
}

/**
 * Get orders count
 * 
 * @since 1.0.0
 * @return string
 */
if ( ! function_exists( 'wc_account_genius_orders_count' ) ) {
  function wc_account_genius_orders_count() {
      $orders = wc_get_orders( apply_filters( 'wc_account_genius_orders_count_args', [
          'status'   => [ 'pending', 'processing', 'completed', 'on-hold', 'failed' ],
          'customer' => get_current_user_id(),
          'return'   => 'ids',
          'limit'    => - 1,
          'paginate' => false,
      ] ) );

      echo count( $orders );
  }
}

/**
 * Display endpoint titles in My account page
 * 
 * @since 1.0.0
 * @return string
 */
if ( ! function_exists( 'wc_account_genius_endpoint_titles' ) ) {
    function wc_account_genius_endpoint_titles() {
        global $wp;

        $endpoints = wc_get_account_menu_items();
        $title = esc_html_x( 'Minha conta', 'front-end', 'wc-account-genius' );

        foreach ( $endpoints as $endpoint => $label ) {
            if ( isset( $wp->query_vars[ $endpoint ] ) ) {
                $title = $label;
            } elseif ( isset( $wp->query_vars['orders'] ) ) {
                $title = esc_html_x( 'Histórico de pedidos', 'front-end', 'wc-account-genius' );
                break;
            } elseif ( isset( $wp->query_vars['add-payment-method'] ) ) {
                $title = esc_html_x( 'Métodos de pagamento', 'front-end', 'wc-account-genius' );
                break;
            } elseif ( isset( $wp->query_vars['edit-address'] ) ) {
                $title = esc_html_x( 'Meus endereços', 'front-end', 'wc-account-genius' );
                break;
            } elseif ( isset( $wp->query_vars['page'] ) || empty( $wp->query_vars ) ) {
                // Dashboard is not an endpoint, so needs a custom check.
                $title = esc_html_x( 'Painel', 'front-end', 'wc-account-genius' );
                break;
            }
        }

        echo apply_filters( 'wc_account_genius_endpoint_titles', $title );
    }
}

/**
 * Get orders limit
 * 
 * @since 1.0.0
 * @return string
 */
if ( ! function_exists( 'wc_account_orders_limit_per_page' ) ) {
  function wc_account_orders_limit_per_page( $args ) {
      // Set the posts per page
      $args['posts_per_page'] = wc_account_get_woocommerce_my_account_orders_limit();
      return $args;
  }
}

if ( ! function_exists( 'wc_account_get_woocommerce_my_account_orders_limit' ) ) {
  function wc_account_get_woocommerce_my_account_orders_limit() {
      return apply_filters( 'wc_account_get_woocommerce_my_account_orders_limit', 5 );
  }
}

if ( ! function_exists( 'silicon_woocommerce_save_account_form_profile_pic_field' ) ) {
  function silicon_woocommerce_save_account_form_profile_pic_field( $user_id ) {
      if ( ! current_user_can( 'edit_user', $user_id ) ) { return true; }
      update_user_meta( $user_id, '_silicon_custom_avatar_id', absint( $_POST['silicon_custom_avatar_id'] ) );
  
  }
}

if ( ! function_exists( 'silicon_row_open' ) ) {
  function silicon_row_open() { ?>
      <div class="row"><?php
  }
}

if ( ! function_exists( 'silicon_row_close' ) ) {
  function silicon_row_close() { ?>
      </div><?php
  }
}

/**
 * Get checkout address fields
 * 
 * @since 1.0.0
 * @return string
 */
if ( ! function_exists( 'wc_account_get_checkout_address_fields' ) ) {
  function wc_account_get_checkout_address_fields( $fields ) {
      foreach ( $fields as $field => &$args ) {
          switch ( $field ) {
              case 'first_name':
              case 'last_name':
              case 'company':
              case 'billing_phone':
                  $args['class'] = [ 'form-group', 'col-sm-6' ];
                  $args['input_class'] = [ 'form-control' ];
                  $args['label_class'] = [ 'form-label' ];
                  break;

              case 'country':
                  $args['class'] = [ 'form-group', 'col-sm-6', 'address-field', 'update_totals_on_change' ];
                  $args['input_class'] = [ 'form-control' ];
                  $args['label_class'] = [ 'form-label' ];
                  break;

              case 'address_1':
              case 'address_2':
                  $args['class'] = [ 'form-group', 'col-sm-12', 'address-field' ];
                  $args['input_class'] = [ 'form-control' ];
                  $args['label_class'] = [ 'form-label' ];
                  break;

              case 'city':
              case 'state':
              case 'postcode':
                  $args['class'] = [ 'form-group', 'col-sm-6', 'address-field' ];
                  $args['input_class'] = [ 'form-control' ];
                  $args['label_class'] = [ 'form-label' ];
                  break;
              case 'billing_email':
                  $args['class'] = [ 'form-group', 'col-sm-12' ];
                  $args['input_class'] = [ 'form-control' ];
                  $args['label_class'] = [ 'form-label' ];
                  break;
          }
      }

      return $fields;
  }
}

/**
 * Get checkout fields and apply classes
 * 
 * @since 1.0.0
 * @return string
 */
if ( ! function_exists( 'wc_account_get_checkout_fields' ) ) {
  function wc_account_get_checkout_fields( $fields ) {
      if ( ! empty( $fields['account'] ) ) {
          if ( 'no' === get_option( 'woocommerce_registration_generate_username' ) ) {
              $fields['account']['account_username']['class'] = [ 'form-group', 'col-sm-12' ];
              $fields['account']['account_username']['input_class'] = [ 'form-control' ];
          }

          if ( 'no' === get_option( 'woocommerce_registration_generate_password' ) ) {
              $fields['account']['account_password']['class'] = [ 'form-group', 'col-sm-12' ];
              $fields['account']['account_password']['input_class'] = [ 'form-control' ];
          }
      }

      if ( ! empty( $fields['order'] ) ) {
          if ( isset( $fields['order']['order_comments'] ) ) {
              $fields['order']['order_comments']['class'] = [ 'form-group' ];
              $fields['order']['order_comments']['input_class'] = [ 'form-control' ];
          }
      }

      return $fields;
  }
}

if ( ! function_exists( 'silicon_wc_order_item_name' ) ) {
  function silicon_wc_order_item_name( $name, $item ){
      $variation_id = $item['variation_id'];
      if( $variation_id > 0 ) {
          $product_id = $item['product_id'];
          $_product = wc_get_product( $product_id );
          $product_name = $_product->get_title();
          $_name = $product_name;
          $variation_name = str_replace( $product_name . ' -', '', $item->get_name() );
          $_name .= '<span class="text-muted d-block mt-1 fw-normal">'. $variation_name .'</span>';
          $updated_name = str_replace( $item->get_name(), $_name, $name );
          $name = $updated_name;
      }
      
      return $name;
  }
}
add_filter( 'woocommerce_order_item_name', 'silicon_wc_order_item_name', 10, 2 );


function wc_account_genius_display_slanted_background() {
    $options = get_option( 'wc-account-genius-setting' );

    if ( is_account_page() && isset( $options['enable_background_slanted'] ) == 'yes' ) {
        echo '<div class="wc-account-genius-slanted-bg-header position-relative bg-primary">
            <div class="cs-shape cs-shape-bottom cs-shape-slant bg-secondary d-lg-block">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 3000 260">
                    <polygon fill="currentColor" points="0,257 0,260 3000,260 3000,0"></polygon>
                </svg>
            </div>
        </div>';

        echo '<style>
            .wc-account-genius-my-account {
                padding: 0 !important;
                margin-top: -420px;
            }
        </style>';
    }
}

add_action( 'besa_after_theme_header', 'wc_account_genius_display_slanted_background' );
/*
if( function_exists( 'besa_tbay_body_classes' ) ) {
    add_action( 'besa_after_theme_header', 'wc_account_genius_display_slanted_background' );
}*/

add_filter('get_avatar', 'wc_account_genius_change_avatar', 1, 5);
function wc_account_genius_change_avatar($avatar, $id_or_email, $size, $default, $alt) {
    $user = false;

    if (is_numeric($id_or_email)) {
        $id = (int)$id_or_email;
        $user = get_user_by('id', $id);
    } elseif (is_object($id_or_email)) {
        if (!empty($id_or_email->user_id)) {
            $id = (int)$id_or_email->user_id;
            $user = get_user_by('id', $id);
        }
    } else {
        $user = get_user_by('email', $id_or_email);
    }

    if ($user && is_object($user)) {
        $picture_id = get_user_meta($user->data->ID, 'profile_pic', true);
        if (!empty($picture_id)) {
            $avatar = wp_get_attachment_image_src($picture_id);
            if ($avatar) {
                $avatar = $avatar[0];
                $avatar = '<img loading="lazy" alt="' . $alt . '" src="' . $avatar . '" class="d-block rounded-circle mx-auto my-2 avatar avatar-' . $size . ' photo" height="' . $size . '" width="' . $size . '">';
            }
        }
    }

    return $avatar;
}

add_action('init', 'upload_woo_avatar');

function upload_woo_avatar() {
    $user_id = get_current_user_id();

    if (isset($_GET['action']) && $_GET['action'] == 'delete') {
        $picture_id = get_user_meta($user_id, 'profile_pic', true);
        delete_user_meta($user_id, 'profile_pic');
        // wp_delete_attachment($picture_id, true); // either one will work
        wp_delete_post($picture_id, true);
    }

    if (isset($_FILES['profile_pic']) && $_FILES['profile_pic'] && trim($_FILES['profile_pic']['name']) != '') {
        $upload_result = wc_account_genius_replace_avatar_wordpress($_FILES['profile_pic']);

        if (is_int($upload_result)) {
            update_user_meta($user_id, 'profile_pic', $upload_result);
            wc_add_notice(__('Foto de perfil alterada com sucesso!', 'wc-account-genius'), 'success');
        } else {
            wc_add_notice($upload_result, 'error');
        }
    }
}

function wc_account_genius_replace_avatar_wordpress($profilepicture) {
    $wordpress_upload_dir = wp_upload_dir();
    $new_file_path = $wordpress_upload_dir['path'] . '/' . $profilepicture['name'];

    if (empty($profilepicture)) {
        return __('Nenhum arquivo selecionado.', 'wc-account-genius');
    }

    if ($profilepicture['error']) {
        return $profilepicture['error'];
    }

    if (!in_array($profilepicture['type'], array('image/jpeg', 'image/png', 'image/gif'))) {
        return __('Este tipo de arquivo não é permitido.', 'wc-account-genius');
    }

    if (!move_uploaded_file($profilepicture['tmp_name'], $new_file_path)) {
        return __('Erro ao enviar arquivo.', 'wc-account-genius');
    }

    $attachment = array(
        'post_mime_type' => $profilepicture['type'],
        'post_title' => sanitize_file_name($profilepicture['name']),
        'post_content' => '',
        'post_status' => 'inherit'
    );

    $attach_id = wp_insert_attachment($attachment, $new_file_path);
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    $attach_data = wp_generate_attachment_metadata($attach_id, $new_file_path);
    wp_update_attachment_metadata($attach_id, $attach_data);
    return $attach_id;
}


/**
 * Create a form for upload avatar in popup
 * 
 * @since 1.0.0
 * @package MeuMouse.com
 */
function wc_account_genius_form_upload_avatar() {
    echo '<div id="drop-area" class="wc-account-genius-avatar-actions">';
        echo '<div class="drag-text">';
            echo '<i class="bx bx-image"></i>';
            echo __('Arraste e solte a imagem aqui', 'wc-account-genius');
            echo '</div>';
            echo '<div class="file-list">';
            echo '</div>';
            echo '<form enctype="multipart/form-data" action="'. wc_customer_edit_account_url() .'" method="POST">';
                echo '<div class="wc-account-genius-drag-and-drop-file">';
                    echo '<div class="custom-file">';
                        echo '<input type="file" class="custom-file-input" id="upload-file-avatar" name="profile_pic" hidden>';
                        echo '<label class="custom-file-label mb-4" for="upload-file-avatar">'. __('Ou clique para procurar seu arquivo', 'wc-account-genius') .'</label>';
                    echo '</div>';
                echo '</div>';
                echo '<button class="btn btn-primary button-loading" type="submit" id="wc-account-genius-send-avatar" disabled>'. __('Enviar', 'wc-account-genius') .'</button>';
        echo '</form>';
    echo '</div>';

    echo '<div class="wc-account-genius-info-upload">';
        echo '<i class="bx bx-info-circle me-1"></i>';
        echo '<span>'. __('Envie uma imagem JPG, JPEG, GIF ou PNG. Tamanho máximo de 5MB.', 'wc-account-genius') .'</span>';
    echo '</div>';
}

add_shortcode('wc_account_genius_avatar_upload', 'wc_account_genius_form_upload_avatar');
