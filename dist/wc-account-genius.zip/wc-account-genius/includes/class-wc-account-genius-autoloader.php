<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

/**
 * Main class autoloader
 * 
 * @package MeuMouse.com
 * @version 1.0.0
 */
class Wc_Account_Genius_Autoloader {

	public $wc_account_genius_settings = array();
  
  public function __construct() {
    // load plugin setting
    if( empty( $this->wc_account_genius_settings ) ) {
      $this->wc_account_genius_settings = get_option( 'wc-account-genius-setting' );
    }

    $options = get_option( 'wc-account-genius-setting' );

    // load templates if is active
    if( isset( $options['replace_default_template_my_account'] ) == 'yes' ) {
      include_once WC_ACCOUNT_GENIUS_DIR . 'includes/wc-account-genius-functions.php';
      add_filter( 'woocommerce_locate_template', array( $this, 'replace_my_account_templates' ), 10, 3 );
    }

    add_action( 'wp_enqueue_scripts', array( $this, 'my_account_load_styles' ), 999 );

    // load alerts styles if is active
    if ( isset( $options['replace_default_notices'] ) == 'yes' ) {
      add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_other_styles' ) );
    }

    // load popup avatar
    if( isset( $options['enable_upload_avatar'] ) == 'yes' ) {
      add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_avatar_upload' ) );
    }
  }


  /**
	 * Plugin default settings for texts
   * 
	 * @return array
	 * @since 1.0.0
	 * @access public
	 */
	public $default_settings = array(
    'primary_main_color' => '#008aff',
  );

  
  /**
	 * Function for get plugin general settings
	 * 
	 * @return string 
	 * @since 1.0.0
	 * @access public
	 */
	public function getSetting( $key ) {
    if( ! empty( $this->wc_account_genius_settings) && isset( $this->wc_account_genius_settings[ $key ] ) ) {
      return $this->wc_account_genius_settings[ $key ];
    }

    if( isset( $this->default_settings[ $key ] ) ) {
      return $this->default_settings[ $key ];
    }

    return false;
  }


  /**
   * Replace WooCommerce templates in my account page
   * 
   * @since 1.0.0
   * @return void
   */
  public function replace_my_account_templates( $template, $template_name, $template_path ) {
    $options = get_option( 'wc-account-genius-setting' );
    
    // replace downloads template
    if ( $template_name === 'myaccount/downloads.php' ) {
      $template = plugin_dir_path(__FILE__) . '/templates/my-account/downloads.php';
    }

    // replace form edit account template
    if ( $template_name === 'myaccount/form-edit-account.php' ) {
      $template = plugin_dir_path(__FILE__) . '/templates/my-account/form-edit-account.php';
    }

    // replace form edit address template
    if ( $template_name === 'myaccount/form-edit-address.php' ) {
      $template = plugin_dir_path(__FILE__) . '/templates/my-account/form-edit-address.php';
    }

    // replace form login template
    if ( $template_name === 'myaccount/form-login.php' ) {
      $template = plugin_dir_path(__FILE__) . '/templates/my-account/form-login.php';
    }

    // replace form lost password template
    if ( $template_name === 'myaccount/form-lost-password.php' ) {
      $template = plugin_dir_path(__FILE__) . '/templates/my-account/form-lost-password.php';
    }

    // replace my account template
    if ( $template_name === 'myaccount/my-account.php' ) {
      $template = plugin_dir_path(__FILE__) . '/templates/my-account/my-account.php';
    }

    // replace my addresses template
    if ( $template_name === 'myaccount/my-address.php' ) {
      $template = plugin_dir_path(__FILE__) . '/templates/my-account/my-address.php';
    }

    // replace navigation template
    if ( $template_name === 'myaccount/navigation.php' ) {
      $template = plugin_dir_path(__FILE__) . '/templates/my-account/navigation.php';
    }

    // replace orders template
    if ( $template_name === 'myaccount/orders.php' ) {
      $template = plugin_dir_path(__FILE__) . '/templates/my-account/orders.php';
    }

    // replace view order template
    if ( $template_name === 'myaccount/view-order.php' ) {
      $template = plugin_dir_path(__FILE__) . '/templates/my-account/view-order.php';
    }

    // replace form tracking template
    if ( $template_name === 'order/form-tracking.php' ) {
      $template = plugin_dir_path(__FILE__) . '/templates/order/form-tracking.php';
    }

    // replace order again template
    if ( $template_name === 'order/order-again.php' ) {
      $template = plugin_dir_path(__FILE__) . '/templates/order/order-again.php';
    }

    // replace order details template
    if ( $template_name === 'order/order-details.php' ) {
      $template = plugin_dir_path(__FILE__) . '/templates/order/order-details.php';
    }

    // replace order details customer template
    if ( $template_name === 'order/order-details-customer.php' ) {
      $template = plugin_dir_path(__FILE__) . '/templates/order/order-details-customer.php';
    }

    // replace order details item template
    if ( $template_name === 'order/order-details-item.php' ) {
      $template = plugin_dir_path(__FILE__) . '/templates/order/order-details-item.php';
    }

    // replace order downloads template
    if ( $template_name === 'order/order-downloads.php' ) {
      $template = plugin_dir_path(__FILE__) . '/templates/order/order-downloads.php';
    }

    // replace tracking template
    if ( $template_name === 'order/tracking.php' ) {
      $template = plugin_dir_path(__FILE__) . '/templates/order/tracking.php';
    }

    // replace error notice template
    if ( isset( $options['replace_default_notices'] ) == 'yes' && $template_name === 'notices/error.php' ) {
      $template = plugin_dir_path(__FILE__) . '/templates/notices/error.php';
    }

    // replace success notice template
    if ( isset( $options['replace_default_notices'] ) == 'yes' && $template_name === 'notices/success.php' ) {
      $template = plugin_dir_path(__FILE__) . '/templates/notices/success.php';
    }

    // replace info notice template
    if ( isset( $options['replace_default_notices'] ) == 'yes' && $template_name === 'notices/notice.php' ) {
      $template = plugin_dir_path(__FILE__) . '/templates/notices/notice.php';
    }

    return $template;
  }


  /**
   * Load styles in My account page
   * 
   * @since 1.0.0
   * @return void
   */
  public function my_account_load_styles() {
    $version = Wc_Account_Genius()->version;
    $options = get_option( 'wc-account-genius-setting' );

    if( is_account_page() && isset( $options['replace_default_template_my_account'] ) == 'yes' ) {
      wp_enqueue_style( 'wc-account-genius-front-styles', WC_ACCOUNT_GENIUS_URL . 'assets/css/wc-account-genius-front-styles.css', array(), $version );
      wp_enqueue_script( 'wc-account-genius-front-scripts', WC_ACCOUNT_GENIUS_URL . 'assets/js/wc-account-genius-front-scripts.js', array('jquery'), $version );
    }
  }


  /**
   * Load alerts styles in front-end
   * 
   * @since 1.0.0
   * @return void
   */
  public function enqueue_other_styles() {
    $version = Wc_Account_Genius()->version;
    $options = get_option( 'wc-account-genius-setting' );

    wp_enqueue_style( 'wc-account-genius-notice-styles', WC_ACCOUNT_GENIUS_URL . 'assets/css/wc-account-genius-notice-styles.css', array(), $version );
    
    // enable icons
    if( isset( $options['enable_icons'] ) == 'yes' ) {
      wp_enqueue_style( 'box-icons-lib-style', WC_ACCOUNT_GENIUS_URL . 'assets/vendor/boxicons/css/boxicons.min.css', array(), '2.1.4' );
    }
  }


  /**
   * Load upload avatar styles and scripts
   * 
   * @since 1.0.0
   * @return void
   */
  public function enqueue_avatar_upload() {
    $version = Wc_Account_Genius()->version;

    wp_enqueue_style( 'wc-account-genius-avatar-styles', WC_ACCOUNT_GENIUS_URL . 'assets/css/wc-account-genius-popup-avatar-styles.css', array(), $version );
    wp_enqueue_script( 'wc-account-genius-avatar-scripts', WC_ACCOUNT_GENIUS_URL . 'assets/js/wc-account-genius-popup-avatar-scripts.js', array(), $version );
  }

}

new Wc_Account_Genius_Autoloader();