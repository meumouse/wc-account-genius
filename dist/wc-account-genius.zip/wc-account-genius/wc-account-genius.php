<?php

/**
 * Plugin Name: 			Account Genius - Modelo profissional de página Minha conta para WooCommerce
 * Description: 			Extensão que altera o modelo de página minha conta padrão do WooCommerce por um modelo profissional e responsivo.
 * Plugin URI: 				https://meumouse.com/plugins/account-genius/
 * Author: 					MeuMouse.com
 * Author URI: 				https://meumouse.com/
 * Version: 				1.1.0
 * WC requires at least: 	5.0.0
 * WC tested up to: 		7.7.2
 * Requires PHP: 			7.2
 * Tested up to:      		6.2.2
 * Text Domain: 			wc-account-genius
 * Domain Path: 			/languages
 * License: 				GPL2
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

// Define WC_ACCOUNT_GENIUS_PLUGIN_FILE.
if ( ! defined( 'WC_ACCOUNT_GENIUS_PLUGIN_FILE' ) ) {
	define( 'WC_ACCOUNT_GENIUS_PLUGIN_FILE', __FILE__ );
}

if ( ! class_exists( 'Wc_Account_Genius' ) ) {
  
/**
 * Main Wc_Account_Genius Class
 *
 * @class Wc_Account_Genius
 * @version 1.0.0
 * @since 1.0.0
 * @package MeuMouse.com
 */
final class Wc_Account_Genius {

		/**
		 * Wc_Account_Genius The single instance of Wc_Account_Genius.
		 *
		 * @var object
		 * @since 1.0.0
		 */
		private static $instance = null;

		/**
		 * The token
		 *
		 * @var string
		 * @since 1.0.0
		 */
		public $token;

		/**
		 * The version number
		 *
		 * @var string
		 * @since 1.0.0
		 */
		public $version;

		/**
		 * Constructor function.
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function __construct() {
			$this->token = 'wc-account-genius';
			$this->version = '1.1.0';
			
			add_action( 'plugins_loaded', array( $this, 'wc_account_genius_load_checker' ), 5 );
		}
		

		/**
		 * Check requeriments on load plugin
		 * 
		 * @since 1.0.0
		 * @return void
		 */
		public function wc_account_genius_load_checker() {
			if ( !function_exists( 'is_plugin_active' ) ) {
				include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
			}

			// Display notice if PHP version is bottom 7.2
			if ( version_compare( phpversion(), '7.2', '<' ) ) {
				add_action( 'admin_notices', array( $this, 'wc_account_genius_php_version_notice' ) );
				return;
			}

			// check if WooCommerce is active
			if ( is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
				add_action( 'init', array( $this, 'load_plugin_textdomain' ), -1 );
				add_action( 'plugins_loaded', array( $this, 'setup_constants' ), 15 );
				add_action( 'plugins_loaded', array( $this, 'setup_includes' ), 20 );
				add_action( 'plugins_loaded', array( $this, 'wc_account_genius_update_checker' ), 30 );
				add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( $this, 'wc_account_genius_plugin_links' ), 10, 4 );
			} else {
				deactivate_plugins( 'woo-custom-installments/woo-custom-installments.php' );
				add_action( 'admin_notices', array( $this, 'woo_custom_installments_wc_deactivate_notice' ) );
			}

			// display notice if WooCommerce version is bottom 6.0
			if ( is_plugin_active( 'woocommerce/woocommerce.php' ) && version_compare( WC_VERSION, '6.0', '<' ) ) {
				add_action( 'admin_notices', array( $this, 'woo_custom_installments_wc_version_notice' ) );
				return;
			}
		}

		/**
		 * Main Wc_Account_Genius Instance
		 *
		 * Ensures only one instance of Wc_Account_Genius is loaded or can be loaded.
		 *
		 * @since 1.0.0
		 * @static
		 * @see Wc_Account_Genius()
		 * @return Main Wc_Account_Genius instance
		 */
		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Setup plugin constants
		 *
		 * @since  1.0.0
		 * @return void
		 */
		public function setup_constants() {

			// Plugin Folder Path.
			if ( ! defined( 'WC_ACCOUNT_GENIUS_DIR' ) ) {
				define( 'WC_ACCOUNT_GENIUS_DIR', plugin_dir_path( __FILE__ ) );
			}

			// Plugin Folder URL.
			if ( ! defined( 'WC_ACCOUNT_GENIUS_URL' ) ) {
				define( 'WC_ACCOUNT_GENIUS_URL', plugin_dir_url( __FILE__ ) );
			}

			// Plugin Root File.
			if ( ! defined( 'WC_ACCOUNT_GENIUS_FILE' ) ) {
				define( 'WC_ACCOUNT_GENIUS_FILE', __FILE__ );
			}

			$this->define( 'WC_ACCOUNT_GENIUS_ABSPATH', dirname( WC_ACCOUNT_GENIUS_FILE ) . '/' );
			$this->define( 'WC_ACCOUNT_GENIUS_VERSION', $this->version );
		}


		/**
		 * Define constant if not already set.
		 *
		 * @param string $name  Constant name.
		 * @param string|bool $value Constant value.
		 */
		private function define( $name, $value ) {
			if ( ! defined( $name ) ) {
				define( $name, $value );
			}
		}


		/**
		 * What type of request is this?
		 *
		 * @param  string $type admin, ajax, cron or wciend.
		 * @return bool
		 */
		private function is_request( $type ) {
			switch ( $type ) {
				case 'admin':
					return is_admin();
				case 'ajax':
					return defined( 'DOING_AJAX' );
				case 'cron':
					return defined( 'DOING_CRON' );
			}
		}


		/**
		 * Include required files
		 *
		 * @since  1.0.0
		 * @return void
		 */
		public function setup_includes() {

			/**
			 * Class init plugin
			 * 
			 * @since 1.0.0
			 */
			include_once WC_ACCOUNT_GENIUS_DIR . 'includes/class-wc-account-genius-autoloader.php';

			/**
			 * Admin options
			 * 
			 * @since 1.0.0
			 */
			include_once WC_ACCOUNT_GENIUS_DIR . 'includes/admin/class-wc-account-genius-admin-options.php';
		}

		/**
		 * PHP version notice
		 * 
		 * @since 1.0.0
		 */
		public function wc_account_genius_php_version_notice() {
			echo '<div class="notice is-dismissible error">
					<p>' . __( '<strong>Account Genius</strong> requer a versão do PHP 7.2 ou maior. Contate o suporte da sua hospedagem para realizar a atualização.', 'wc-account-genius' ) . '</p>
				</div>';
		}

		/**
		 * Plugin update checker
		 * 
		 * @since 1.0.0
		 */
		public function wc_account_genius_update_checker(){
			require WC_ACCOUNT_GENIUS_DIR .'includes/updater/plugin-update-checker.php';
			$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker( 'https://raw.githubusercontent.com/meumouse/wc-account-genius/main/updater/update-checker.json', __FILE__, 'wc-account-genius' );
		}

		/**
		 * Plugin action links
		 * 
		 * @since 1.0.0
		 * @return array
		 */
		public function wc_account_genius_plugin_links( $action_links ) {
			$plugins_links = array(
				'<a href="' . admin_url( 'admin.php?page=wc-account-genius' ) . '">'. __( 'Configurar', 'wc-account-genius' ) .'</a>',
				'<a href="https://meumouse.com/docs/plugins/account-genius/" target="_blank">'. __( 'Ajuda', 'wc-account-genius' ) .'</a>'
			);

			return array_merge( $plugins_links, $action_links );
		}

		/**
		 * Load the plugin text domain for translation.
		 */
		public static function load_plugin_textdomain() {
			load_plugin_textdomain( 'wc-account-genius', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
		}

		/**
		 * Get the plugin url.
		 *
		 * @return string
		 */
		public function plugin_url() {
			return untrailingslashit( plugins_url( '/', WC_ACCOUNT_GENIUS_PLUGIN_FILE ) );
		}

		/**
		 * Cloning is forbidden.
		 *
		 * @since 1.0.0
		 */
		public function __clone() {
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Trapaceando?', 'wc-account-genius' ), '1.0.0' );
		}

		/**
		 * Unserializing instances of this class is forbidden.
		 *
		 * @since 1.0.0
		 */
		public function __wakeup() {
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Trapaceando?', 'wc-account-genius' ), '1.0.0' );
		}

	}
}

/**
 * Returns the main instance of Wc_Account_Genius to prevent the need to use globals.
 *
 * @since  1.0.0
 * @return object Wc_Account_Genius
 */
function Wc_Account_Genius() { //phpcs:ignore WordPress.NamingConventions.ValidFunctionName.FunctionNameInvalid
	return Wc_Account_Genius::instance();
}

/**
 * Initialise the plugin
 */
Wc_Account_Genius();