<?php

/**
 * Plugin Name: 			Account Genius para WooCommerce
 * Description: 			Extensão que altera o modelo de página minha conta padrão do WooCommerce por um modelo profissional e responsivo.
 * Plugin URI: 				https://meumouse.com/plugins/account-genius/
 * Author: 					MeuMouse.com
 * Author URI: 				https://meumouse.com/
 * Version: 				1.8.0
 * WC requires at least: 	5.0.0
 * WC tested up to: 		8.4.0
 * Requires PHP: 			7.2
 * Tested up to:      		6.4.2
 * Text Domain: 			wc-account-genius
 * Domain Path: 			/languages
 * License: 				GPL2
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Wc_Account_Genius' ) ) {
  
/**
 * Main Wc_Account_Genius Class
 *
 * @class Wc_Account_Genius
 * @version 1.0.0
 * @since 1.0.0
 * @package MeuMouse.com
 */
class Wc_Account_Genius {

		/**
		 * Wc_Account_Genius The single instance of Wc_Account_Genius.
		 *
		 * @var object
		 * @since 1.0.0
		 */
		private static $instance = null;

		/**
		 * The slug
		 *
		 * @var string
		 * @since 1.0.0
		 */
		public static $slug = 'wc-account-genius';

		/**
		 * The version number
		 *
		 * @var string
		 * @since 1.0.0
		 */
		public static $version = '1.8.0';

		/**
		 * Constructor function.
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function __construct() {
			$this->setup_constants();
			
			add_action( 'init', array( $this, 'load_plugin_textdomain' ), -1 );
			add_action( 'plugins_loaded', array( $this, 'wc_account_genius_load_checker' ), 5 );
		}
		

		/**
		 * Check requeriments on load plugin
		 * 
		 * @since 1.0.0
		 * @return void
		 */
		public function wc_account_genius_load_checker() {
			if ( !function_exists( 'is_plugin_active' ) ) {
				include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
			}

			// check if WooCommerce is active
			if ( is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
				add_action( 'before_woocommerce_init', array( $this, 'setup_hpos_compatibility' ) );
				add_action( 'plugins_loaded', array( $this, 'setup_includes' ), 10 );
				add_filter( 'plugin_action_links_' . WC_ACCOUNT_GENIUS_BASE, array( $this, 'wc_account_genius_plugin_links' ), 10, 4 );
			} else {
				deactivate_plugins( 'wc-account-genius/wc-account-genius.php' );
				add_action( 'admin_notices', array( $this, 'wc_account_genius_wc_deactivate_notice' ) );
			}

			// display notice if WooCommerce version is bottom 6.0
			if ( is_plugin_active( 'woocommerce/woocommerce.php' ) && version_compare( WC_VERSION, '6.0', '<' ) ) {
				add_action( 'admin_notices', array( $this, 'wc_account_genius_wc_version_notice' ) );
				return;
			}

			// Display notice if PHP version is bottom 7.2
			if ( version_compare( phpversion(), '7.2', '<' ) ) {
				add_action( 'admin_notices', array( $this, 'wc_account_genius_php_version_notice' ) );
				return;
			}
		}


		/**
		 * Setp compatibility with HPOS/Custom order table feature of WooCommerce.
		 *
		 * @since 1.6.0
		 * @return void
		 */
		public static function setup_hpos_compatibility() {
			if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
				\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', WC_ACCOUNT_GENIUS_PLUGIN_FILE, true );
			}
		}
		

		/**
		 * Main Wc_Account_Genius Instance
		 *
		 * Ensures only one instance of Wc_Account_Genius is loaded or can be loaded.
		 *
		 * @since 1.0.0
		 * @static
		 * @see Wc_Account_Genius()
		 * @return Main Wc_Account_Genius instance
		 */
		public static function run() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}


		/**
		 * Setup plugin constants
		 *
		 * @since  1.0.0
		 * @return void
		 */
		public function setup_constants() {
			$this->define( 'WC_ACCOUNT_GENIUS_BASE', plugin_basename( __FILE__ ) );
			$this->define( 'WC_ACCOUNT_GENIUS_DIR', plugin_dir_path( __FILE__ ) );
			$this->define( 'WC_ACCOUNT_GENIUS_URL', plugin_dir_url( __FILE__ ) );
			$this->define( 'WC_ACCOUNT_GENIUS_FILE', __FILE__ );
			$this->define( 'WC_ACCOUNT_GENIUS_ABSPATH', dirname( WC_ACCOUNT_GENIUS_FILE ) . '/' );
			$this->define( 'WC_ACCOUNT_GENIUS_PLUGIN_FILE', __FILE__ );
			$this->define( 'WC_ACCOUNT_GENIUS_VERSION', self::$version );
			$this->define( 'WC_ACCOUNT_GENIUS_SLUG', self::$slug );
		}

		/**
		 * Define constant if not already set.
		 *
		 * @param string $name  Constant name.
		 * @param string|bool $value Constant value.
		 */
		private function define( $name, $value ) {
			if ( ! defined( $name ) ) {
				define( $name, $value );
			}
		}


		/**
		 * What type of request is this?
		 *
		 * @param  string $type admin, ajax, cron or wciend.
		 * @return bool
		 */
		private function is_request( $type ) {
			switch ( $type ) {
				case 'admin':
					return is_admin();
				case 'ajax':
					return defined( 'DOING_AJAX' );
				case 'cron':
					return defined( 'DOING_CRON' );
			}
		}


		/**
		 * Include required files
		 *
		 * @since  1.0.0
		 * @return void
		 */
		public function setup_includes() {

			/**
			 * Class init plugin
			 * 
			 * @since 1.0.0
			 */
			include_once WC_ACCOUNT_GENIUS_DIR . '/includes/class-wc-account-genius-init.php';

			/**
			 * Admin options
			 * 
			 * @since 1.0.0
			 */
			include_once WC_ACCOUNT_GENIUS_DIR . '/includes/admin/class-wc-account-genius-admin-options.php';

			/**
			 * Plugin functions
			 * 
			 * @since 1.0.0
			 */
			include_once WC_ACCOUNT_GENIUS_DIR . '/includes/wc-account-genius-functions.php';

			/**
			 * Custom colors
			 * 
			 * @since 1.0.0
			 */
			include_once WC_ACCOUNT_GENIUS_DIR . '/includes/classes/class-wc-account-genius-custom-colors.php';

			/**
			 * Update checker
			 * 
			 * @since 1.5.0
			 */
			include_once WC_ACCOUNT_GENIUS_DIR . '/includes/classes/class-wc-account-genius-updater.php';

			/**
			 * Connect API
			 * 
			 * @since 1.6.0
			 */
			include_once WC_ACCOUNT_GENIUS_DIR . '/includes/classes/class-wc-account-genius-api.php';
		}

		/**
		 * PHP version notice
		 * 
		 * @since 1.0.0
		 */
		public function wc_account_genius_php_version_notice() {
			echo '<div class="notice is-dismissible error">
					<p>' . __( '<strong>Account Genius para WooCommerce</strong> requer a versão do PHP 7.2 ou maior. Contate o suporte da sua hospedagem para realizar a atualização.', 'wc-account-genius' ) . '</p>
				</div>';
		}


		/**
		 * WooCommerce version notice
		 * 
		 * @since 1.0.0
		 */
		public function wc_account_genius_wc_version_notice() {
			echo '<div class="notice is-dismissible error">
					<p>' . __( '<strong>Account Genius para WooCommerce</strong> requer a versão do WooCommerce 6.0 ou maior. Faça a atualização do plugin WooCommerce.', 'wc-account-genius' ) . '</p>
				</div>';
		}


		/**
		 * Notice if WooCommerce is deactivate
		 * 
		 * @since 1.0.0
		 */
		public function wc_account_genius_wc_deactivate_notice() {
			if ( !current_user_can('install_plugins') ) {
				return;
			}

			echo '<div class="notice is-dismissible error">
					<p>' . __( '<strong>Account Genius para WooCommerce</strong> requer que <strong>WooCommerce</strong> esteja instalado e ativado.', 'wc-account-genius' ) . '</p>
				</div>';
		}


		/**
		 * Plugin action links
		 * 
		 * @since 1.0.0
		 * @return array
		 */
		public function wc_account_genius_plugin_links( $action_links ) {
			$plugins_links = array(
				'<a href="' . admin_url( 'admin.php?page=wc-account-genius' ) . '">'. __( 'Configurar', 'wc-account-genius' ) .'</a>',
				'<a href="https://meumouse.com/docs-category/account-genius/" target="_blank">'. __( 'Ajuda', 'wc-account-genius' ) .'</a>'
			);

			return array_merge( $plugins_links, $action_links );
		}


		/**
		 * Load the plugin text domain for translation.
		 */
		public static function load_plugin_textdomain() {
			load_plugin_textdomain( 'wc-account-genius', false, dirname( WC_ACCOUNT_GENIUS_BASE ) . '/languages/' );
		}


		/**
		 * Cloning is forbidden.
		 *
		 * @since 1.0.0
		 */
		public function __clone() {
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Trapaceando?', 'wc-account-genius' ), '1.0.0' );
		}


		/**
		 * Unserializing instances of this class is forbidden.
		 *
		 * @since 1.0.0
		 */
		public function __wakeup() {
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Trapaceando?', 'wc-account-genius' ), '1.0.0' );
		}
	}
}

/**
 * Initialise the plugin
 */
Wc_Account_Genius::run();