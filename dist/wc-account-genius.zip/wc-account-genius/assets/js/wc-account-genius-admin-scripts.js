(function ($) {
    "use strict";

	/**
	 * Hide toast on click button or after 5 seconds
	 * 
	 * @since 1.0.0
	 */
	jQuery( function($) {
		$('.hide-toast').click( function() {
			$('.update-notice-ag-wc').fadeOut('fast');
		});

		setTimeout( function() {
			$('.update-notice-ag-wc').fadeOut('fast');
		}, 3000);
	});


	/**
	 * Save options in AJAX
	 * 
	 * @since 1.5.0
	 */
	jQuery( function($) {
		let settingsForm = $('form[name="wc-account-genius"]');
		let originalValues = settingsForm.serialize();
		var notificationDelay;

		settingsForm.on('change', function() {
			if (settingsForm.serialize() != originalValues) {
				ajax_save_options(); // send option serialized on change
			}
		});

		function ajax_save_options() {
			$.ajax({
				url: account_genius_admin_params.ajax_url,
				type: 'POST',
				data: {
					action: 'account_genius_ajax_save_options',
					form_data: settingsForm.serialize(),
				},
				success: function(response) {
					try {
						var responseData = JSON.parse(response); // Parse the JSON response

						if (responseData.status === 'success') {
							originalValues = settingsForm.serialize();
							$('.update-notice-ag-wc').addClass('active');
							
							if (notificationDelay) {
								clearTimeout(notificationDelay);
							}
				
							notificationDelay = setTimeout( function() {
								$('.update-notice-ag-wc').fadeOut('fast', function() {
									$(this).removeClass('active').css('display', '');
								});
							}, 3000);
						}
					} catch (error) {
						console.log(error);
					}
				}
			});
		}
	});

})(jQuery);