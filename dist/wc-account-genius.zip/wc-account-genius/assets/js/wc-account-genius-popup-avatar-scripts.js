/**
 * Popup upload avatar
 * 
 * @since 1.0.0
 * @package MeuMouse.com
 */
jQuery( function($) {
    const openUploadAvatar = $('#upload-avatar');
    const uploadContainer = $('#upload-avatar-container');
    const closePopup = $('#close-popup-avatar');
    
    openUploadAvatar.on('click', function() {
      uploadContainer.addClass('show');
    });
    
    uploadContainer.on('click', function(event) {
    if (event.target === this) {
      $(this).removeClass('show');
    }
    });
  
    closePopup.on('click', function() {
      uploadContainer.removeClass('show');
    })
});


/**
 * Drag and drop avatar
 * 
 * @since 1.0.0
 * @package MeuMouse.com
 */
jQuery( function($) {
  var $dropArea = $('#drop-area');
  var $fileInput = $('#upload-file-avatar');
  var $fileList = $('.file-list');
  var $sendButton = $('#wc-account-genius-send-avatar');

  // Manipulador de evento para quando o cursor estiver sobre a área de drop
  $dropArea.on('dragover', function(e) {
    e.preventDefault();
    $dropArea.addClass('drag-over');
  });

  // Manipulador de evento para quando o cursor sair da área de drop
  $dropArea.on('dragleave', function(e) {
    e.preventDefault();
    $dropArea.removeClass('drag-over');
  });

  // Manipulador de evento para quando um arquivo for solto na área de drop
  $dropArea.on('drop', function(e) {
    e.preventDefault();
    $dropArea.removeClass('drag-over');

    var files = e.originalEvent.dataTransfer.files;
    handleFiles(files);
  });

  // Manipulador de evento para quando a área de drop for clicada
  $dropArea.on('click', function(e) {
    $fileInput.click();
  });

  // Manipulador de evento para quando um arquivo for selecionado usando o botão de seleção de arquivo
  $fileInput.on('change', function(e) {
    var files = e.target.files;
    handleFiles(files);
  });

  // Processa os arquivos selecionados
  function handleFiles(files) {
    $fileList.empty(); // Limpa a lista de arquivos

    for (var i = 0; i < files.length; i++) {
      var file = files[i];
      var listItem = $('<div class="file-item"></div>').text(file.name);
      $fileList.append(listItem);
    }

    // Ativa ou desativa o botão "Enviar" dependendo se existem arquivos selecionados
    if (files.length > 0) {
      $sendButton.prop('disabled', false);
    } else {
      $sendButton.prop('disabled', true);
    }
  }
});