(function ($) {
    "use strict";

	/**
	 * Activate tabs
	 * 
	 * @since 1.6.0
	 */
	jQuery( function($) {
		// Reads the index stored in localStorage, if it exists
		let activeTabIndex = localStorage.getItem('active_tab_index_account_genius');

		if (activeTabIndex === null) {
			// If it is null, activate the general tab
			$('.wc-account-genius-wrapper a.nav-tab[href="#options-settings"]').click();
		} else {
			$('.wc-account-genius-wrapper a.nav-tab').eq(activeTabIndex).click();
		}
	});
	  
	$(document).on('click', '.wc-account-genius-wrapper a.nav-tab', function() {
		// Stores the index of the active tab in localStorage
		let tabIndex = $(this).index();
		localStorage.setItem('active_tab_index_account_genius', tabIndex);
		
		let attrHref = $(this).attr('href');
		
		$('.wc-account-genius-wrapper a.nav-tab').removeClass('nav-tab-active');
		$('.wc-account-genius-form .nav-content').removeClass('active');
		$(this).addClass('nav-tab-active');
		$('.wc-account-genius-form').find(attrHref).addClass('active');
		
		return false;
	});

	/**
	 * Hide toast on click button or after 5 seconds
	 * 
	 * @since 1.0.0
	 */
	jQuery( function($) {
		$('.hide-toast').click( function() {
			$('.toast, .update-notice-ag-wc').fadeOut('fast');
		});

		setTimeout( function() {
			$('.toast, .update-notice-ag-wc').fadeOut('fast');
		}, 3000);
	});


	/**
	 * Display loader and hide span on click
	 * 
	 * @since 1.6.0
	 */
	jQuery( function($) {
		$('.button-loading').on('click', function() {
			let $btn = $(this);
			let expireDate = $btn.text();
			let btnWidth = $btn.width();
			let btnHeight = $btn.height();

			// keep original width and height
			$btn.width(btnWidth);
			$btn.height(btnHeight);

			// Add spinner inside button
			$btn.html('<span class="spinner-border spinner-border-sm"></span>');
		});

		// Prevent keypress enter
		$('.form-control').keypress( function(event) {
			if (event.keyCode === 13) {
				event.preventDefault();
			}
		});
	});


	/**
	 * Save options in AJAX
	 * 
	 * @since 1.5.0
	 */
	jQuery( function($) {
		let settingsForm = $('form[name="wc-account-genius"]');
		let originalValues = settingsForm.serialize();
		var notificationDelay;

		settingsForm.on('change', function() {
			if (settingsForm.serialize() != originalValues) {
				ajax_save_options(); // send option serialized on change
			}
		});

		function ajax_save_options() {
			$.ajax({
				url: account_genius_admin_params.ajax_url,
				type: 'POST',
				data: {
					action: 'account_genius_ajax_save_options',
					form_data: settingsForm.serialize(),
				},
				success: function(response) {
					try {
						var responseData = JSON.parse(response); // Parse the JSON response

						if (responseData.status === 'success') {
							originalValues = settingsForm.serialize();
							display_update_notice();
						}
					} catch (error) {
						console.log(error);
					}
				}
			});
		}

		// display update notices
		function display_update_notice() {
			$('.update-notice-ag-wc').addClass('active');
	
			if (notificationDelay) {
				clearTimeout(notificationDelay);
			}
	
			notificationDelay = setTimeout( function() {
				$('.update-notice-ag-wc').fadeOut('fast', function() {
					$(this).removeClass('active').css('display', '');
				});
			}, 3000);
		}
	});


	/**
	 * Sortable and create new tabs
	 * 
	 * @since 1.8.0
	 */
	jQuery(document).ready( function($) {
		let sortable_tabs = $('#account-tabs .sortable').sortable({
			draggable: 'li:not(.blocked)',
			animation: 250,
			forceFallback: true,
			removeCloneOnHide: true,
			touchStartThreshold: 5,
			onSort: function(event) {
				reorderTabs();
			}
		});

		function reorderTabs() {
			var tabsList = $('#account-tabs ul.sortable');
		
			// Get all items in the list
			var tabs = tabsList.children('li');
		
			// Update the data-priority attribute based on the current order
			tabs.each(function (index) {
				var priority = index + 1;
				$(this).data('priority', priority);
				$(this).attr('data-priority', priority); // Update the attribute as well
		
				// Update the input hidden with class "change-priority"
				$(this).find('.change-priority').val(priority).trigger('change');
			});
		
			// Sort items based on the updated data-priority attribute
			tabs.sort (function(a, b) {
				var priorityA = parseInt($(a).data('priority'));
				var priorityB = parseInt($(b).data('priority'));
		
				return priorityA - priorityB;
			});
		
			// Update the list with the reordered tabs
			tabsList.html(tabs);
		}

		// Function to order elements based on data-priority
		function sortByPriority() {
			var tabsList = $("#account-tabs ul.sortable");
			var tabs = tabsList.children("li");

			tabs.sort(function (a, b) {
				var priorityA = parseInt($(a).data("priority"), 10);
				var priorityB = parseInt($(b).data("priority"), 10);

				return priorityA - priorityB;
			});

			// Remove elements from the list
			tabs.detach();

			// Add the ordered elements back to the list
			tabsList.append(tabs);
		}

		// Call the function to sort when loading the page
		sortByPriority();

		// open popup
		$(document).on('click', '.account-genius-tabs-trigger', function(e) {
			e.preventDefault();
			
			let get_tab = $(e.target).closest('li.tab-item').addClass('blocked');

			get_tab.children('.account-genius-tabs-container').addClass('show');
		});

		// close popup on click close button
		$(document).on('click', '.account-genius-tabs-close-popup', function(e) {
			e.preventDefault();

			$(this).closest('.account-genius-tabs-container').removeClass('show');
			$('.account-genius-tabs-trigger').closest('li.tab-item').removeClass('blocked');
		});
	
		// close popup if click outside the container
		$(document).on('click', '.account-genius-tabs-container', function(e) {
			if (e.target === this) {
				$(this).removeClass('show');
				$('.account-genius-tabs-trigger').closest('li.tab-item').removeClass('blocked');
			}
		});

		// add icon on <i> element on paste event
		$(document).on('paste', '.set-icon-tab', function(e) {
			setTimeout( function() {
				let pastedValue = $(e.target).val();
				let matches = pastedValue.match(/class=['"]([^'"]+)['"]/);

				if (matches && matches.length > 1) {
					$(e.target).val(matches[1]);
					$(e.target).siblings('.display-icon-tab').children('i').removeClass().addClass(matches[1]);
					$('.tab-item.blocked').children('i').removeClass().addClass(matches[1]);
				}
			}, 10);
		});

		// add icon on <i> element on keyup event
		$(document).on('keyup', '.set-icon-tab', function(e) {
			let this_val = $(e.target).val();

			$(e.target).siblings('.display-icon-tab').children('i').removeClass().addClass(this_val);
			$('.tab-item.blocked').children('i').removeClass().addClass(this_val);
		});

		// change tab name on keyup
		$(document).on('keyup', '.get-name-tab', function(e) {
			let this_val = $(e.target).val();

			$('.tab-item.blocked').find('.account-genius-tabs-header').find('.tab-name').text(this_val);
			$('.tab-item.blocked').children('.tab-name').text(this_val);
		});

		// deactive tab on click toggle switch
		$(document).on('click', '.toggle-active-tab', function(e) {
			let checked = $(e.target).prop('checked');
			let target = $('.tab-item.blocked');

			$(target).toggleClass('active', checked).removeClass('inactive');
			$(target).toggleClass('inactive', !checked).removeClass('active');
		});

		// format input text for slug
		$(document).on('blur', '.set-endpoint-tab', function() {
			var endpoint_value = $(this).val().trim();
			
			// If input .set-endpoint-tab is empty
			if (endpoint_value === '') {
				// Get the text from the nearest input .get-name-tab
				var name_value = $(this).closest('.tab-item').find('.get-name-tab').val().trim();
				
				// Format for URL replacing spaces with dashes
				endpoint_value = name_value.replace(/\s+/g, '-').toLowerCase();
			} else {
				// If not empty, format for URL replacing spaces with dashes
				endpoint_value = endpoint_value.replace(/\s+/g, '-').toLowerCase();
			}
		
			// Remove accents, special characters, and anything not in the URL-safe character set
			endpoint_value = endpoint_value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9-]/g, '');
		
			// Update the value of input .set-endpoint-tab with the formatted version
			$(this).val(endpoint_value);
		});		

		// show/hide redirect link input
		$(document).on('click', '.enable-redirect-link', function() {
			if ( $(this).prop('checked') ) {
				$('.tab-item.blocked').find('tr.redirect-link').removeClass('d-none');
				$('.tab-item.blocked').find('tr.redirect-link-content').addClass('d-none');
			} else {
				$('.tab-item.blocked').find('tr.redirect-link').addClass('d-none');
				$('.tab-item.blocked').find('tr.redirect-link-content').removeClass('d-none');
			}
		});

		// exclude tab action
		$(document).on('click', '.exclude-tab', function(e) {
			e.preventDefault();

			let tab_item = $(this).closest('li.tab-item');
			let index = tab_item.find('.set-array-key-tab').val();
			var notificationDelay;

			// Fade out the tab with animation
			tab_item.fadeOut(400, function() {
				// Remove the tab from the DOM after fade-out
				tab_item.remove();
			});

			$.ajax({
				url: account_genius_admin_params.ajax_url,
				type: 'POST',
				data: {
					action: 'remove_tab_from_options',
					tab_to_remove: index,
				},
				success: function(response) {
					try {
						var responseData = JSON.parse(response);
						console.log('Parsed response:', responseData);
	
						if (responseData && responseData.status === 'success') {
							$('.update-notice-ag-wc').addClass('active');
	
							if (notificationDelay) {
								clearTimeout(notificationDelay);
							}
					
							notificationDelay = setTimeout( function() {
								$('.update-notice-ag-wc').fadeOut('fast', function() {
									$(this).removeClass('active').css('display', '');
								});
							}, 3000);
						} else {
							console.error('Invalid JSON response or missing "status" field:', response);
						}
					} catch (error) {
						console.error('Error parsing JSON:', error);
					}
				},
				error: function(xhr, textStatus, errorThrown) {
					console.error('AJAX request failed:', textStatus, errorThrown);
				}
			});
		});

		function updateTabId(tabElement) {
			var endpointValue = tabElement.find('.set-endpoint-tab').val();
			var idValue = endpointValue ? endpointValue.replace(/[^a-z0-9]/gi, '') : '';
		
			// Atualiza o ID da guia
			tabElement.attr('id', idValue);
		}

		// add new tab item
		$(document).on('click', '#add-new-tab-item', function(e) {
			e.preventDefault();
			
			let tabs_container = $('#account-tabs .sortable');
			var index = tabs_container.find('li').length;

			tabs_container.append(`<li id="${index}" class="tab-item" data-native="no" data-priority="">
				<input type="hidden" class="change-priority" name="account_tabs[${index}][priority]" value="${index}">
				<input type="hidden" class="get-native-tab" name="account_tabs[${index}][native]" value="no">
				<input type="hidden" class="get-endpoint-tab" name="account_tabs[${index}][endpoint]" value="${account_genius_admin_params.new_tab_endpoint}">
				<input type="hidden" class="set-array-key-tab" name="account_tabs[${index}][array_key]" value="${index}">
				
				<i class="bx bx-info-circle"></i>
				<span class="tab-name show">${account_genius_admin_params.new_tab}</span>
				<button class="account-genius-tabs-trigger btn btn-sm btn-outline-primary ms-auto rounded-3 show" data-trigger="">${account_genius_admin_params.edit_tab}</button>
			
				<div class="account-genius-tabs-container">
					<div class="account-genius-tabs-content">
						<div class="account-genius-tabs-header">
							<h5 class="account-genius-tabs-popup-title">${account_genius_admin_params.tab_title} <strong class="tab-name">${account_genius_admin_params.new_tab}</strong></h5>
							<button class="account-genius-tabs-close-popup btn-close fs-lg" aria-label="${account_genius_admin_params.close_popup}"></button>
						</div>
						<div class="tab-conditions">
							<table class="form-table">
								<tbody>
									<tr>
										<th class="w-50">
											${account_genius_admin_params.tab_name}
											<span class="wc-account-genius-description">${account_genius_admin_params.tab_name_description}</span>
										</th>
										<td class="w-50">
											<input type="text" class="get-name-tab form-control" name="account_tabs[${index}][label]" value="${account_genius_admin_params.new_tab}">
										</td>
									</tr>
									<tr>
										<th class="w-50">
											${account_genius_admin_params.endpoint_tab}
											<span class="wc-account-genius-description">${account_genius_admin_params.endpoint_tab_description}</span>
										</th>
										<td class="w-50">
											<input type="text" class="set-endpoint-tab form-control" name="account_tabs[${index}][endpoint]" value="${account_genius_admin_params.new_tab_endpoint}">
										</td>
									</tr>
									<tr>
										<th class="w-50">
											${account_genius_admin_params.icon_tab}
											<span class="wc-account-genius-description">${account_genius_admin_params.icon_tab_description}</span>
											<a class="fancy-link mt-2" href="https://boxicons.com/" target="_blank">${account_genius_admin_params.icon_link}</a>
										</th>
										<td class="w-50">
											<div class="input-group">
												<span class="display-icon-tab fs-xg input-group-text">
													<i class="bx bx-info-circle"></i>
												</span>
												<input type="text" class="set-icon-tab form-control" name="account_tabs[${index}][icon]" value="bx bx-info-circle" placeholder="${account_genius_admin_params.icon_placeholder}">
											</div>
										</td>
									</tr>
									<tr class="redirect-link-content">
										<th class="w-50">
											${account_genius_admin_params.tab_content_title}
											<span class="wc-account-genius-description">${account_genius_admin_params.tab_content_description}</span>
										</th>
										<td class="w-50">
											<div class="form-check form-switch">
												<textarea class="form-control" name="account_tabs[${index}][content]"></textarea>
											</div>
										</td>
									</tr>
									<tr>
										<th class="w-50">
											${account_genius_admin_params.active_redirect_tab_title}
											<span class="wc-account-genius-description">${account_genius_admin_params.active_redirect_tab_description}</span>
										</th>
										<td class="w-50">
											<div class="form-check form-switch">
												<input type="checkbox" class="toggle-switch enable-redirect-link" name="account_tabs[${index}][redirect]" value="yes" />
											</div>
										</td>
									</tr>
									<tr class="redirect-link d-none">
										<th class="w-50">
											${account_genius_admin_params.redirect_tab_link_title}
											<span class="wc-account-genius-description">${account_genius_admin_params.redirect_tab_link_description}</span>
										</th>
										<td class="w-50">
											<div class="form-check form-switch">
												<input type="text" class="form-control" name="account_tabs[${index}][link]" value="" />
											</div>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
				<button class="btn btn-outline-danger btn-icon ms-3 rounded-3 exclude-tab" data-exclude="">
					<i class="bx bx-trash-alt fs-lg"></i>
				</button>
			</li>`);

			tabs_container.find(`#account_tabs\\[${index}\\]\\[endpoint\\]`).on('input', function () {
				updateTabId($(this).closest('li'));
			});

			reorderTabs();
		});
	});
	
})(jQuery);