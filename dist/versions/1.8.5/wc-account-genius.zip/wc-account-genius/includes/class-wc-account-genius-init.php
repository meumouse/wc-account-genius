<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Init class plugin
 * 
 * @version 1.0.0
 * @version 1.8.5
 * @package MeuMouse.com
 */
class Wc_Account_Genius_Init {

  public $responseObj;
  public $licenseMessage;
  public $showMessage = false;
  public $activateLicense = false;
  public $deactivateLicense = false;

  /**
   * Construct function
   * 
   * @since 1.0.0
   * @version 1.8.5
   * @return void
   */
  public function __construct() {
    add_action( 'admin_init', array( $this, 'account_genius_set_default_options' ) );
    add_action( 'admin_init', array( $this, 'set_default_tabs_options' ) );
    add_action( 'admin_init', array( $this, 'account_genius_api_connection' ) );

    // load templates if is active
    if ( self::get_setting('replace_default_template_my_account') === 'yes' ) {
      add_filter( 'woocommerce_locate_template', array( $this, 'replace_my_account_templates' ), 10, 3 );
    }
  }


  /**
   * Set default options
   * 
   * @since 1.0.0
   * @version 1.8.5
   * @return array
   */
  public function set_default_data_options() {
    return array(
      'replace_default_template_my_account' => 'yes',
      'replace_default_notices' => 'yes',
      'primary_main_color' => '#008aff',
      'enable_icons' => 'yes',
      'display_background_slanted' => 'yes',
      'enable_upload_avatar' => 'yes',
    );
  }


  /**
   * Gets the items from the array and inserts them into the option if it is empty,
   * or adds new items with default value to the option
   * 
   * @since 1.0.0
   * @return void
   */
  public function account_genius_set_default_options() {
    $get_options = $this->set_default_data_options();
    $default_options = get_option('wc-account-genius-setting', array());

    if ( empty( $default_options ) ) {
        $options = $get_options;
        update_option('wc-account-genius-setting', $options);
    } else {
        $options = $default_options;

        foreach ( $get_options as $key => $value ) {
            if ( !isset( $options[$key] ) ) {
                $options[$key] = $value;
            }
        }

        update_option('wc-account-genius-setting', $options);
    }
  }


  /**
   * Get default tabs
   * 
   * @since 1.8.0
   * @return array $tabs
   */
  public function get_default_tabs() {
    $get_default_endpoints = 

    $tabs = array(
      'orders' => array(
          'id' => 'woocommerce_myaccount_orders_endpoint',
          'endpoint' => get_option('woocommerce_myaccount_orders_endpoint'),
          'icon' => 'bx bx-cart',
          'label' => 'Meus pedidos',
          'native' => 'yes',
          'priority' => '1',
          'enabled' => 'yes',
      ),
      'downloads' => array(
          'id' => 'woocommerce_myaccount_downloads_endpoint',
          'endpoint' => get_option('woocommerce_myaccount_downloads_endpoint'),
          'icon' => 'bx bx-cloud-download',
          'label' => 'Downloads',
          'native' => 'yes',
          'priority' => '2',
          'enabled' => 'yes',
      ),
      'edit-address' => array(
          'id' => 'woocommerce_myaccount_edit_address_endpoint',
          'endpoint' => get_option('woocommerce_myaccount_edit_address_endpoint'),
          'icon' => 'bx bx-map',
          'label' => 'Meus endereços',
          'native' => 'yes',
          'priority' => '3',
          'enabled' => 'yes',
      ),
      'edit-account' => array(
          'id' => 'woocommerce_myaccount_edit_account_endpoint',
          'endpoint' => get_option('woocommerce_myaccount_edit_account_endpoint'),
          'icon' => 'bx bx-user',
          'label' => 'Detalhes da conta',
          'native' => 'yes',
          'priority' => '4',
          'enabled' => 'yes',
      ),
      'payment-methods' => array(
          'id' => 'woocommerce_myaccount_payment_methods_endpoint',
          'endpoint' => get_option('woocommerce_myaccount_payment_methods_endpoint'),
          'icon' => 'bx bx-credit-card-alt',
          'label' => 'Formas de pagamento',
          'native' => 'yes',
          'priority' => '5',
          'enabled' => 'yes',
      ),
      'customer-logout' => array(
          'id' => 'woocommerce_logout_endpoint',
          'endpoint' => get_option('woocommerce_logout_endpoint'),
          'icon' => 'bx bx-log-out',
          'label' => 'Sair',
          'native' => 'yes',
          'priority' => '6',
          'enabled' => 'yes',
      ),
    );

    return $tabs;
  }


  /**
   * Init default options tab
   * 
   * @since 1.8.0
   * @return void
   */
  public function set_default_tabs_options() {
    $default_tabs = $this->get_default_tabs();
    $default_option_tabs = get_option('account_genius_get_tabs_options', array());
    $default_option_tabs = maybe_unserialize($default_option_tabs);

    if ( empty( $default_option_tabs ) ) {
        $tabs = array();

        foreach ( $default_tabs as $key => $value ) {
            $tabs[$key] = $value;
        }

        update_option('account_genius_get_tabs_options', maybe_serialize( $tabs ) );
    } else {
        // Add subscription tab if WC_Subscriptions class is present and tab does not exist
        if ( class_exists('WC_Subscriptions') && !isset( $default_option_tabs['subscription'] ) ) {
            $subscription_tab = array(
                'subscription' => array(
                    'id' => 'woocommerce_myaccount_subscriptions_endpoint',
                    'endpoint' => get_option('woocommerce_myaccount_subscriptions_endpoint'),
                    'icon' => 'bx bx-basket',
                    'label' => 'Minhas assinaturas',
                    'native' => 'yes',
                    'priority' => '7',
                    'enabled' => 'yes',
                ),
            );

            // Add subscription tab to existing options
            $default_option_tabs = array_merge($default_option_tabs, $subscription_tab);
            update_option('account_genius_get_tabs_options', maybe_serialize( $default_option_tabs ));
        }
    }
  }


  /**
	 * Checks if the option exists and returns the indicated array item
	 * 
	 * @since 1.0.0
   * @version 1.8.5
   * @param $key | Array key
   * @return mixed | string or false
	 */
  public static function get_setting( $key ) {
    $default_options = get_option('wc-account-genius-setting', array());

    // check if array key exists and return key
    if ( isset( $default_options[$key] ) ) {
        return $default_options[$key];
    }

    return false;
  }


  /**
   * Replace WooCommerce templates in my account page
   * 
   * @since 1.0.0
   * @version 1.8.5
   * @param string $template
   * @param string $template_name
   * @param string $template_path
   * @return string $template
   */
  public function replace_my_account_templates( $template, $template_name, $template_path ) {
    // replace downloads template
    if ( $template_name === 'myaccount/downloads.php' ) {
      $template = WC_ACCOUNT_GENIUS_INC_DIR . 'templates/my-account/downloads.php';
    }

    // replace form edit account template
    if ( $template_name === 'myaccount/form-edit-account.php' ) {
      $template = WC_ACCOUNT_GENIUS_INC_DIR . 'templates/my-account/form-edit-account.php';
    }

    // replace form edit address template
    if ( $template_name === 'myaccount/form-edit-address.php' ) {
      $template = WC_ACCOUNT_GENIUS_INC_DIR . 'templates/my-account/form-edit-address.php';
    }

    // replace form login template
    if ( is_account_page() && $template_name === 'myaccount/form-login.php' ) {
      $template = WC_ACCOUNT_GENIUS_INC_DIR . 'templates/my-account/form-login.php';
    }

    // replace form lost password template
    if ( $template_name === 'myaccount/form-lost-password.php' ) {
      $template = WC_ACCOUNT_GENIUS_INC_DIR . 'templates/my-account/form-lost-password.php';
    }

    // replace form lost password confirmation template
    if ( $template_name === 'myaccount/lost-password-confirmation.php' ) {
      $template = WC_ACCOUNT_GENIUS_INC_DIR . 'templates/my-account/lost-password-confirmation.php';
    }

    // replace my account template
    if ( $template_name === 'myaccount/my-account.php' ) {
      $template = WC_ACCOUNT_GENIUS_INC_DIR . 'templates/my-account/my-account.php';
    }

    // replace my addresses template
    if ( $template_name === 'myaccount/my-address.php' ) {
      $template = WC_ACCOUNT_GENIUS_INC_DIR . 'templates/my-account/my-address.php';
    }

    // replace navigation template
    if ( $template_name === 'myaccount/navigation.php' ) {
      $template = WC_ACCOUNT_GENIUS_INC_DIR . 'templates/my-account/navigation.php';
    }

    // replace orders template
    if ( $template_name === 'myaccount/orders.php' ) {
      $template = WC_ACCOUNT_GENIUS_INC_DIR . 'templates/my-account/orders.php';
    }

    // replace view order template
    if ( $template_name === 'myaccount/view-order.php' ) {
      $template = WC_ACCOUNT_GENIUS_INC_DIR . 'templates/my-account/view-order.php';
    }

    // replace form tracking template
    if ( $template_name === 'order/form-tracking.php' ) {
      $template = WC_ACCOUNT_GENIUS_INC_DIR . 'templates/order/form-tracking.php';
    }

    // replace order again template
    if ( $template_name === 'order/order-again.php' ) {
      $template = WC_ACCOUNT_GENIUS_INC_DIR . 'templates/order/order-again.php';
    }

    // replace order details template
    if ( $template_name === 'order/order-details.php' ) {
      $template = WC_ACCOUNT_GENIUS_INC_DIR . 'templates/order/order-details.php';
    }

    // replace order details customer template
    if ( $template_name === 'order/order-details-customer.php' ) {
      $template = WC_ACCOUNT_GENIUS_INC_DIR . 'templates/order/order-details-customer.php';
    }

    // replace order details item template
    if ( $template_name === 'order/order-details-item.php' ) {
      $template = WC_ACCOUNT_GENIUS_INC_DIR . 'templates/order/order-details-item.php';
    }

    // replace order downloads template
    if ( $template_name === 'order/order-downloads.php' ) {
      $template = WC_ACCOUNT_GENIUS_INC_DIR . 'templates/order/order-downloads.php';
    }

    // replace tracking template
    if ( $template_name === 'order/tracking.php' ) {
      $template = WC_ACCOUNT_GENIUS_INC_DIR . 'templates/order/tracking.php';
    }

    // replace my subscriptions template  
    if ( class_exists( 'WC_Subscriptions' ) && $template_name === 'myaccount/my-subscriptions.php' ) {
      $template = WC_ACCOUNT_GENIUS_INC_DIR . 'templates/my-account/my-subscriptions.php';
    }

    if ( is_account_page() ) {
        // replace error notice template
        if ( self::get_setting('replace_default_notices') === 'yes' && $template_name === 'notices/error.php' ) {
          $template = WC_ACCOUNT_GENIUS_INC_DIR . 'templates/notices/error.php';
        }

        // replace success notice template
        if ( self::get_setting('replace_default_notices') === 'yes' && $template_name === 'notices/success.php' ) {
          $template = WC_ACCOUNT_GENIUS_INC_DIR . 'templates/notices/success.php';
        }

        // replace info notice template
        if ( self::get_setting('replace_default_notices') === 'yes' && $template_name === 'notices/notice.php' ) {
          $template = WC_ACCOUNT_GENIUS_INC_DIR . 'templates/notices/notice.php';
        }
    }

    return $template;
  }


  /**
   * Load API settings
   * 
   * @since 1.6.0
   * @version 1.8.5
   * @return void
   */
  public function account_genius_api_connection() {
    if ( current_user_can('manage_options') ) {
        $this->responseObj = new stdClass();
        $message = '';
        $license_key = get_option( 'wc_account_genius_license_key', '' );
    
        // Save settings on active license
        if (  isset( $_POST['wc_account_genius_active_license'] ) ) {
            delete_transient('wc_account_genius_api_request_cache');
            delete_transient('account_genius_license_response_object');
            
            update_option( 'wc_account_genius_license_key', $_POST );
            $license_key = !empty( $_POST['wc_account_genius_license_key'] ) ? $_POST['wc_account_genius_license_key'] : '';
            update_option( 'wc_account_genius_license_key', $license_key ) || add_option('wc_account_genius_license_key', $license_key );
        }

        if ( ! self::license_valid() ) {
            update_option( 'wc_account_genius_license_status', 'invalid' );
        }
    
        // Check on the server if the license is valid and update responses and options
        if ( Wc_Account_Genius_Api::CheckWPPlugin( $license_key, $this->licenseMessage, $this->responseObj, WC_ACCOUNT_GENIUS_FILE ) ) {
            if ( $this->responseObj && $this->responseObj->is_valid ) {
                update_option('wc_account_genius_license_status', 'valid');
            } else {
                update_option('wc_account_genius_license_status', 'invalid');
            }

            if ( isset( $_POST['wc_account_genius_active_license'] ) && self::license_valid() ) {
                $this->activateLicense = true;
            }
        } else {
            if ( !empty( $license_key ) && !empty( $this->licenseMessage ) ) {
                $this->showMessage = true;
            }
        }

        // Save settings on deactive license, or remove license status if it is invalid
        if ( isset( $_POST['wc_account_genius_deactive_license'] ) ) {
          if ( Wc_Account_Genius_Api::RemoveLicenseKey( WC_ACCOUNT_GENIUS_FILE, $message ) ) {
              update_option('wc_account_genius_license_status', 'invalid');
              delete_option('wc_account_genius_license_key');

              $this->deactivateLicense = true;
          }
        }

        if ( isset( $_POST['account_genius_clear_activation_cache'] ) || ! self::license_valid() ) {
            delete_transient('wc_account_genius_api_request_cache');
            delete_transient('wc_account_genius_api_response_cache');
            delete_option('account_genius_license_response_object');
        }
    }
  }


  /**
   * Check if license is valid
   * 
   * @since 1.8.5
   * @return bool
   */
  public static function license_valid() {
      $object_query = get_option('account_genius_license_response_object');

      // clear api request and response cache if object is empty
      if ( empty( $object_query ) ) {
        delete_transient('wc_account_genius_api_request_cache');
        delete_transient('wc_account_genius_api_response_cache');
      }

      if ( ! empty( $object_query ) && isset( $object_query->is_valid )  ) {
          return true;
      } elseif ( empty( $object_query->status ) ) {
          delete_option('account_genius_license_response_object');
          
          return false;
      } else {
          update_option( 'wc_account_genius_license_key', '' );

          return false;
      }
  }


  /**
   * Get license title
   * 
   * @since 1.8.5
   * @return string
   */
  public static function license_title() {
      $object_query = get_option('account_genius_license_response_object');

      if ( ! empty( $object_query ) && isset( $object_query->license_title ) ) {
          return $object_query->license_title;
      } else {
          return esc_html__(  'Não disponível', 'wc-account-genius' );
      }
  }


  /**
   * Get license expire date
   * 
   * @since 1.8.5
   * @return string
   */
  public static function license_expire() {
      $object_query = get_option('account_genius_license_response_object');

      if ( ! empty( $object_query ) && isset( $object_query->expire_date ) ) {
          if ( $object_query->expire_date === 'No expiry' ) {
              return esc_html__( 'Nunca expira', 'wc-account-genius' );
          } else {
              if ( strtotime( $object_query->expire_date ) < time() ) {
                  update_option( 'wc_account_genius_license_status', 'invalid' );
                  delete_option('account_genius_license_response_object');

                  return esc_html__( 'Licença expirada', 'wc-account-genius' );
              }

              // get wordpress date format setting
              $date_format = get_option('date_format');

              return date( $date_format, strtotime( $object_query->expire_date ) );
          }
      }
  }

}

new Wc_Account_Genius_Init();