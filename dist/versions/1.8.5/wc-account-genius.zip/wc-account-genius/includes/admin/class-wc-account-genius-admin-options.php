<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Extends main class with admin actions
 * 
 * @since 1.0.0
 * @version 1.8.5
 * @package MeuMouse.com
 */
class Wc_Account_Genius_Admin_Options extends Wc_Account_Genius_Init {

  /**
   * Construct function
   *
   * @since 1.0.0
   * @return void
   */
  public function __construct() {
    parent::__construct();

    add_action( 'admin_menu', array( $this, 'wc_account_genius_admin_menu' ) );
    add_action( 'wp_ajax_account_genius_ajax_save_options', array( $this, 'account_genius_ajax_save_options_callback' ) );
    add_action( 'wp_ajax_remove_tab_from_options', array( $this, 'remove_tab_from_options_callback' ) );
  }


  /**
   * Function for create submenu in settings
   * 
   * @since 1.0.0
   * @access public
   * @return array
   */
  public function wc_account_genius_admin_menu() {
    add_submenu_page(
      'woocommerce', // parent page slug
      esc_html__( 'Account Genius para WooCommerce', 'wc-account-genius'), // page title
      esc_html__( 'Account Genius', 'wc-account-genius'), // submenu title
      'manage_woocommerce', // user capabilities
      'wc-account-genius', // page slug
      array( $this, 'wc_account_genius_settings_page' ) // public function for print content page
    );
  }


  /**
   * Plugin general setting page and save options
   * 
   * @since 1.0.0
   * @access public
   */
  public function wc_account_genius_settings_page() {
    include_once WC_ACCOUNT_GENIUS_DIR . 'includes/admin/settings.php';
  }


  /**
   * Save options in AJAX
   * 
   * @since 1.5.0
   * @return void
   * @package MeuMouse.com
   */
  public function account_genius_ajax_save_options_callback() {
    if ( isset( $_POST['form_data'] ) ) {
        // Convert serialized data into an array
        parse_str( $_POST['form_data'], $form_data );

        $options = get_option('wc-account-genius-setting');
        $options['replace_default_template_my_account'] = isset( $form_data['replace_default_template_my_account'] ) ? 'yes' : 'no';
        $options['replace_default_notices'] = isset( $form_data['replace_default_notices'] ) ? 'yes' : 'no';
        $options['enable_icons'] = isset( $form_data['enable_icons'] ) ? 'yes' : 'no';
        $options['display_background_slanted'] = isset( $form_data['display_background_slanted'] ) ? 'yes' : 'no';
        $options['enable_upload_avatar'] = isset( $form_data['enable_upload_avatar'] ) ? 'yes' : 'no';

        // update data for tabs
        if ( isset( $form_data['account_tabs'] ) && is_array( $form_data['account_tabs'] ) ) {
          $form_data_tabs = $form_data['account_tabs'];
          $get_tabs = get_option('account_genius_get_tabs_options', array());
          $get_tabs = maybe_unserialize($get_tabs);

          // Iterate through the updated data
          foreach ( $form_data_tabs as $index => $tab ) {
              // Update WooCommerce endpoint option if the endpoint is changed
              if ( isset( $tab['native'] ) && $tab['native'] === 'yes' && isset( $tab['endpoint'] ) && $get_tabs[$index]['endpoint'] !== $tab['endpoint'] ) {
                update_option( $get_tabs[$index]['id'], sanitize_text_field( $tab['endpoint'] ) );

                // update permalinks
                flush_rewrite_rules();
              }

              if ( isset( $get_tabs[$index] ) ) {
                if ( !isset( $tab['enabled'] ) ) {
                    $get_tabs[$index]['enabled'] = 'no';
                }

                if ( !isset( $tab['native'] ) ) {
                  $get_tabs[$index]['native'] = 'no';
                }

                if ( !isset( $tab['redirect'] ) ) {
                  $get_tabs[$index]['redirect'] = 'no';
                }

                // Update priority if present in the form data
                if ( isset( $tab['priority'] ) ) {
                    $get_tabs[$index]['priority'] = sanitize_text_field($tab['priority']);
                }

                // Merge updated data with existing tab data
                $get_tabs[$index] = array_merge( $get_tabs[$index], $tab );
              } else {
                  // get array key from new tab
                  if ( ! isset($get_tabs[$index]) ) {
                    $get_tabs[$index]['array_key'] = $tab['array_key'];
                  }

                  if ( !isset( $tab['endpoint'] ) ) {
                    $get_tabs[$index]['endpoint'] = $tab['endpoint'];
                  }

                  // If the tab does not exist, add it to the array
                  $get_tabs[$index] = $tab;
              }
          }

          // Update option with merged data
          update_option('account_genius_get_tabs_options', maybe_serialize( $get_tabs ));
        }

        // Merge the form data with the default options
        $updated_options = wp_parse_args( $form_data, $options );

        // Save the updated options
        update_option('wc-account-genius-setting', $updated_options);

        $response = array(
            'status' => 'success',
            'options' => $updated_options,
        );

        echo wp_json_encode( $response ); // Send JSON response
    }

    wp_die();
  }


  /**
   * Remove tab from options
   * 
   * @since 1.8.0
   * @return void
   */
  public function remove_tab_from_options_callback() {
    if ( isset( $_POST['tab_to_remove'] ) ) {
      $tab_to_remove = sanitize_text_field( $_POST['tab_to_remove'] );
 
      // Get the current tabs options
      $get_tabs = get_option('account_genius_get_tabs_options', array());
      $get_tabs = maybe_unserialize( $get_tabs );
 
      // Remove the tab with the specified index
      if ( isset( $get_tabs[$tab_to_remove] ) ) {
        unset( $get_tabs[$tab_to_remove] );
 
        // Update the tab options
        update_option('account_genius_get_tabs_options', maybe_serialize( $get_tabs ));
      }
 
      $response = array(
        'status' => 'success',
        'tab' => $tab_to_remove,
      );

      echo wp_json_encode( $response ); // Send JSON response
    }
 
    wp_die();
  }
}

new Wc_Account_Genius_Admin_Options();