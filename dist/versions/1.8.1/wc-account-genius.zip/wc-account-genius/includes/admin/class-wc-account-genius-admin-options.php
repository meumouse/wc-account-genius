<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

class Wc_Account_Genius_Admin_Options extends Wc_Account_Genius_Init {

  /**
   * Wc_Account_Genius_Admin constructor.
   *
   * @since 1.0.0
   * @access public
   */
  public function __construct() {
    parent::__construct();

    add_action( 'admin_menu', array( $this, 'wc_account_genius_admin_menu' ) );
    add_action( 'admin_enqueue_scripts', array( $this, 'wc_account_genius_admin_scripts' ) );
    add_action( 'wp_ajax_account_genius_ajax_save_options', array( $this, 'account_genius_ajax_save_options_callback' ) );
    add_action( 'wp_ajax_remove_tab_from_options', array( $this, 'remove_tab_from_options_callback' ) );
  }

  /**
   * Function for create submenu in settings
   * 
   * @since 1.0.0
   * @access public
   * @return array
   */
  public function wc_account_genius_admin_menu() {
    add_submenu_page(
      'woocommerce', // parent page slug
      esc_html__( 'Account Genius para WooCommerce', 'wc-account-genius'), // page title
      esc_html__( 'Account Genius', 'wc-account-genius'), // submenu title
      'manage_woocommerce', // user capabilities
      'wc-account-genius', // page slug
      array( $this, 'wc_account_genius_settings_page' ) // public function for print content page
    );
  }


  /**
   * Plugin general setting page and save options
   * 
   * @since 1.0.0
   * @access public
   */
  public function wc_account_genius_settings_page() {
    include_once WC_ACCOUNT_GENIUS_DIR . 'includes/admin/settings.php';
  }


  /**
   * Enqueue admin scripts in page settings only
   * 
   * @since 1.0.0
   * @return void
   */
  public function wc_account_genius_admin_scripts() {
    $url = $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    
    if ( false !== strpos( $url, 'admin.php?page=wc-account-genius' ) ) {
      wp_enqueue_style( 'wc-account-genius-admin-styles', WC_ACCOUNT_GENIUS_URL . 'assets/admin/css/wc-account-genius-admin-styles.css', array(), WC_ACCOUNT_GENIUS_VERSION );
      wp_enqueue_script( 'wc-account-genius-admin-scripts', WC_ACCOUNT_GENIUS_URL . 'assets/admin/js/wc-account-genius-admin-scripts.js', array('jquery'), WC_ACCOUNT_GENIUS_VERSION );
      wp_enqueue_script( 'sortable-js', WC_ACCOUNT_GENIUS_URL . 'assets/admin/js/sortable.min.js', array('jquery'), '1.15.1' );
      wp_enqueue_script( 'jquery-sortable-js', WC_ACCOUNT_GENIUS_URL . 'assets/admin/js/jquery-sortable-js.js', array('jquery'), WC_ACCOUNT_GENIUS_VERSION );
      
      if ( ! class_exists('Flexify_Dashboard') ) {
        wp_enqueue_style( 'box-icons-lib', WC_ACCOUNT_GENIUS_URL . 'assets/vendor/boxicons/css/boxicons.min.css', array(), '2.1.4' );
      }

      wp_localize_script( 'wc-account-genius-admin-scripts', 'account_genius_admin_params', array(
        'ajax_url' => admin_url( 'admin-ajax.php' ),
        'new_tab' => esc_html__( 'Nova guia', 'wc-account-genius' ),
        'new_tab_endpoint' => esc_html__( 'nova-guia', 'wc-account-genius' ),
        'tab_title' => esc_html__( 'Configurar guia', 'wc-account-genius' ),
        'edit_tab' => esc_html__( 'Editar guia', 'wc-account-genius' ),
        'close_popup' => esc_html__( 'Fechar', 'wc-account-genius' ),
        'tab_name' => esc_html__( 'Nome da guia', 'wc-account-genius' ),
        'tab_name_description' => esc_html__('Define o título que será exibido para esta guia.', 'wc-account-genius' ),
        'endpoint_tab' => esc_html__( 'Endpoint da guia', 'wc-account-genius' ),
        'endpoint_tab_description' => esc_html__('Define o endpoint que será usado como link permanente para esta guia.', 'wc-account-genius' ),
        'icon_tab' => esc_html__( 'Ícone da guia', 'wc-account-genius' ),
        'icon_tab_description' => esc_html__('Define o ícone que será exibido ao lado do título desta guia. Ou deixe em branco para não exibir.', 'wc-account-genius' ),
        'icon_link' => esc_html__('Acessar Boxicons', 'wc-account-genius' ),
        'icon_placeholder' => esc_html__('Classe do ícone Boxicons.', 'wc-account-genius' ),
        'tab_content_title' => esc_html__( 'Conteúdo da guia', 'wc-account-genius' ),
        'tab_content_description' => esc_html__('Coloque aqui o conteúdo que você deseja exibir na guia. É permitido HTML e shortcodes. Ex.: [content id="10580"]', 'wc-account-genius' ),
        'active_redirect_tab_title' => esc_html__( 'Redirecionar para outro link', 'wc-account-genius' ),
        'active_redirect_tab_description' => esc_html__('Quando o usuário acessar esta guia, será redirecionado para outro link do site, ou externo.', 'wc-account-genius' ),
        'redirect_tab_link_title' => esc_html__( 'Link de redirecionamento', 'wc-account-genius' ),
        'redirect_tab_link_description' => esc_html__('Informe o link de destino da guia.', 'wc-account-genius' ),
      ) );
    }
  }


  /**
   * Save options in AJAX
   * 
   * @since 1.5.0
   * @return void
   * @package MeuMouse.com
   */
  public function account_genius_ajax_save_options_callback() {
    if ( isset( $_POST['form_data'] ) ) {
        // Convert serialized data into an array
        parse_str( $_POST['form_data'], $form_data );

        $options = get_option('wc-account-genius-setting');
        $options['replace_default_template_my_account'] = isset( $form_data['replace_default_template_my_account'] ) ? 'yes' : 'no';
        $options['replace_default_notices'] = isset( $form_data['replace_default_notices'] ) ? 'yes' : 'no';
        $options['enable_icons'] = isset( $form_data['enable_icons'] ) ? 'yes' : 'no';
        $options['display_background_slanted'] = isset( $form_data['display_background_slanted'] ) ? 'yes' : 'no';
        $options['enable_upload_avatar'] = isset( $form_data['enable_upload_avatar'] ) ? 'yes' : 'no';

        // update data for tabs
        if ( isset( $form_data['account_tabs'] ) && is_array( $form_data['account_tabs'] ) ) {
          $form_data_tabs = $form_data['account_tabs'];
          $get_tabs = get_option('account_genius_get_tabs_options', array());
          $get_tabs = maybe_unserialize($get_tabs);

          // Iterate through the updated data
          foreach ( $form_data_tabs as $index => $tab ) {
              // Update WooCommerce endpoint option if the endpoint is changed
              if ( isset( $tab['native'] ) && $tab['native'] === 'yes' && isset( $tab['endpoint'] ) && $get_tabs[$index]['endpoint'] !== $tab['endpoint'] ) {
                update_option( $get_tabs[$index]['id'], sanitize_text_field( $tab['endpoint'] ) );

                // update permalinks
                flush_rewrite_rules();
              }

              if ( isset( $get_tabs[$index] ) ) {
                if ( !isset( $tab['enabled'] ) ) {
                    $get_tabs[$index]['enabled'] = 'no';
                }

                if ( !isset( $tab['native'] ) ) {
                  $get_tabs[$index]['native'] = 'no';
                }

                if ( !isset( $tab['redirect'] ) ) {
                  $get_tabs[$index]['redirect'] = 'no';
                }

                // Update priority if present in the form data
                if ( isset( $tab['priority'] ) ) {
                    $get_tabs[$index]['priority'] = sanitize_text_field($tab['priority']);
                }

                // Merge updated data with existing tab data
                $get_tabs[$index] = array_merge( $get_tabs[$index], $tab );
              } else {
                  // get array key from new tab
                  if ( ! isset($get_tabs[$index]) ) {
                    $get_tabs[$index]['array_key'] = $tab['array_key'];
                  }

                  if ( !isset( $tab['endpoint'] ) ) {
                    $get_tabs[$index]['endpoint'] = $tab['endpoint'];
                  }

                  // If the tab does not exist, add it to the array
                  $get_tabs[$index] = $tab;
              }
          }

          // Update option with merged data
          update_option('account_genius_get_tabs_options', maybe_serialize( $get_tabs ));
        }

        // Merge the form data with the default options
        $updated_options = wp_parse_args( $form_data, $options );

        // Save the updated options
        update_option('wc-account-genius-setting', $updated_options);

        $response = array(
            'status' => 'success',
            'options' => $updated_options,
        );

        echo wp_json_encode( $response ); // Send JSON response
    }

    wp_die();
  }


  /**
   * Remove tab from options
   * 
   * @since 1.8.0
   * @return void
   */
  public function remove_tab_from_options_callback() {
    if ( isset( $_POST['tab_to_remove'] ) ) {
      $tab_to_remove = sanitize_text_field( $_POST['tab_to_remove'] );
 
      // Get the current tabs options
      $get_tabs = get_option('account_genius_get_tabs_options', array());
      $get_tabs = maybe_unserialize( $get_tabs );
 
      // Remove the tab with the specified index
      if ( isset( $get_tabs[$tab_to_remove] ) ) {
        unset( $get_tabs[$tab_to_remove] );
 
        // Update the tab options
        update_option('account_genius_get_tabs_options', maybe_serialize( $get_tabs ));
      }
 
      $response = array(
        'status' => 'success',
        'tab' => $tab_to_remove,
      );

      echo wp_json_encode( $response ); // Send JSON response
    }
 
    wp_die();
  }
}

new Wc_Account_Genius_Admin_Options();